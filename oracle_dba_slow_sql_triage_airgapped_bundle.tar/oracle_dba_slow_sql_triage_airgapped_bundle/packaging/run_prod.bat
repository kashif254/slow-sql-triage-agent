@echo off
REM ====================================================================
REM AMS DBA "Slow SQL" Triage Agent - Production Launcher (Windows)
REM ====================================================================

echo [*] Starting AMS DBA "Slow SQL" Triage Agent in Production Mode...
echo [*] Checking Python environment...

python -c "import fastapi, uvicorn" 2>nul
if %errorlevel% neq 0 (
    echo [!] Dependencies missing. Installing requirements...
    pip install -r requirements.txt
)

echo [*] Launching Production ASGI Server on port 8000...
echo [*] Access the application in your browser at: http://localhost:8000
echo [*] Press Ctrl+C to terminate the server.
echo.

uvicorn slow_sql.web.app:app --host 0.0.0.0 --port 8000 --workers 2

"""
ORACLE DBA "Slow SQL" Triage Agent - Server Runner
Reads centralized configuration from config.json and launches the web application.
Supports local workstations and Windows Jump Boxes (e.g., vbaw-spaces-mgt.itsso.gc.ca).
"""

import os
import sys
import json
import time
import threading
import webbrowser
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.json"

def load_config() -> dict:
    """Loads configuration with robust fallback defaults."""
    default_cfg = {
        "server": {
            "bind_host": "0.0.0.0",
            "port": 8000,
            "public_host": "vbaw-spaces-mgt.itsso.gc.ca",
            "auto_open_browser": True
        },
        "triage_defaults": {
            "default_engine": "local",
            "default_provider": "gemini",
            "default_gemini_model": "gemini-1.5-flash",
            "degradation_threshold": 2.0,
            "default_schema_owner": "SH"
        }
    }
    if not CONFIG_PATH.exists():
        return default_cfg
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            user_cfg = json.load(f)
            # Merge shallow keys
            if "server" in user_cfg:
                default_cfg["server"].update(user_cfg["server"])
            if "triage_defaults" in user_cfg:
                default_cfg["triage_defaults"].update(user_cfg["triage_defaults"])
            return default_cfg
    except Exception as e:
        print(f"[!] Warning: Could not read {CONFIG_PATH}: {e}. Using defaults.")
        return default_cfg

def open_browser_delayed(url: str, delay: float = 1.5):
    """Opens browser after server has started listening."""
    def _target():
        time.sleep(delay)
        try:
            webbrowser.open(url)
        except Exception:
            pass
    t = threading.Thread(target=_target, daemon=True)
    t.start()

def main():
    cfg = load_config()
    server_cfg = cfg.get("server", {})
    bind_host = server_cfg.get("bind_host", "0.0.0.0")
    port = int(server_cfg.get("port", 8000))
    public_host = server_cfg.get("public_host", "vbaw-spaces-mgt.itsso.gc.ca")
    auto_open = server_cfg.get("auto_open_browser", True)

    local_url = f"http://127.0.0.1:{port}"
    jumpbox_url = f"http://{public_host}:{port}"

    print("=" * 72)
    print("  ORACLE DBA \"Slow SQL\" Triage Agent - Jump Box & Local Server")
    print("=" * 72)
    print(f" [*] Config File Loaded : {CONFIG_PATH}")
    print(f" [*] Binding Interface  : {bind_host}:{port}")
    print(f" [*] Local Access URL   : {local_url}")
    print(f" [*] Jump Box Share URL : {jumpbox_url}")
    print("=" * 72)
    print(f" Share with your colleagues: {jumpbox_url}")
    print("=" * 72)
    print()

    if auto_open:
        # If binding to 0.0.0.0, open 127.0.0.1 locally for the current user
        open_target = local_url if bind_host in ["0.0.0.0", "127.0.0.1", "localhost"] else jumpbox_url
        open_browser_delayed(open_target)

    import uvicorn
    # Add project root to sys.path so slow_sql is importable
    if str(BASE_DIR) not in sys.path:
        sys.path.insert(0, str(BASE_DIR))

    uvicorn.run(
        "slow_sql.web.app:app",
        host=bind_host,
        port=port,
        reload=False,
        log_level="info"
    )

if __name__ == "__main__":
    main()

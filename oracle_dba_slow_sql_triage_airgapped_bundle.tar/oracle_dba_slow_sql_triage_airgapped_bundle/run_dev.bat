@echo off
REM ====================================================================
REM ORACLE DBA "Slow SQL" Triage Agent - Local Dev Server Launcher (Batch)
REM ====================================================================

echo [*] Starting ORACLE DBA "Slow SQL" Triage Local Dev Server...
echo [*] Working Directory: %~dp0
cd /d "%~dp0"

python -m uvicorn slow_sql.web.app:app --host 127.0.0.1 --port 8000 --reload
pause

"""
AMS DBA "Slow SQL" Triage Agent
Comprehensive Oracle SQL Diagnostic & Triage Tool
"""

__version__ = "1.0.0"

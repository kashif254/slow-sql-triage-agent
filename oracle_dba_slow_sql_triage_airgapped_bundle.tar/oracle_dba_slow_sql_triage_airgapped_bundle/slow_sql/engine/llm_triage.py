"""
Oracle Slow SQL Triage - LLM Connected Engine
Multi-provider adapter supporting Google Gemini, Anthropic Claude, OpenAI, and xAI Grok.
Translates full Oracle diagnostic payloads into expert DBA forensic analysis.
"""

import json
from typing import Dict, Any, Optional
import httpx

ORACLE_DBA_SYSTEM_PROMPT = """You are an elite Principal Oracle Database Performance Tuning Specialist and Oracle ACE Director.
You specialize in deep forensic analysis of Oracle Slow SQL queries using execution plans, SQL Monitor reports,
historical Plan Hash Value (PHV) telemetry, table statistics freshness, and index definitions.

Analyze the provided diagnostic telemetry rigorously. Adhere to Oracle Cost-Based Optimizer (CBO) principles:
1. Identify the exact root cause of the regression (e.g., Stale Statistics, Plan Flip, Missing Composite Index, Unreproduced Baseline).
2. Compare the good PHV vs degraded PHV (elapsed time, CPU, logical I/O buffer gets).
3. Point out why the CBO chose the current plan (e.g. cardinality misestimates from E-Rows vs A-Rows).
4. Evaluate existing indexes vs the predicates. Explain why the leading column rule failed or why a new composite index is required.
5. Provide prescriptive, copy-pasteable Oracle remediation:
   - Statistics Gathering syntax (DBMS_STATS.GATHER_TABLE_STATS)
   - Exact Index DDL (CREATE INDEX ... ONLINE COMPUTE STATISTICS)
   - SQL Plan Management (DBMS_SPM.LOAD_PLANS_FROM_CURSOR_CACHE)
   - Strategic Optimizer Hints (/*+ LEADING(...) INDEX(...) */)

Format your response in structured, professional Markdown with clear sections, tables, and code blocks.
"""

class LLMConnectedTriageEngine:
    """Dispatches diagnostic payloads to the user's chosen LLM provider."""

    def __init__(self, provider: str, api_key: str, model: Optional[str] = None):
        self.provider = provider.lower().strip()
        self.api_key = api_key.strip()
        self.model = model or self._get_default_model(self.provider)

    @staticmethod
    def _get_default_model(provider: str) -> str:
        defaults = {
            "gemini": "gemini-2.0-flash",
            "anthropic": "claude-3-7-sonnet-20250219",
            "openai": "gpt-4o",
            "grok": "grok-2-latest"
        }
        return defaults.get(provider.lower(), "gemini-2.0-flash")

    async def analyze(self, diagnostic_data: Dict[str, Any], offline_findings: Dict[str, Any]) -> Dict[str, Any]:
        """Calls the configured LLM provider and returns the analysis narrative."""
        if not self.api_key:
            raise ValueError(f"No API key provided for {self.provider}. Please supply your key.")

        user_content = self._build_prompt_payload(diagnostic_data, offline_findings)

        if self.provider == "gemini":
            response_text = await self._call_gemini(user_content)
        elif self.provider == "anthropic":
            response_text = await self._call_anthropic(user_content)
        elif self.provider == "openai":
            response_text = await self._call_openai(user_content)
        elif self.provider == "grok":
            response_text = await self._call_grok(user_content)
        else:
            raise ValueError(f"Unsupported LLM provider: {self.provider}. Supported: gemini, anthropic, openai, grok")

        return {
            "engine_mode": f"LLM Connected ({self.provider.upper()} - {self.model})",
            "sql_id": diagnostic_data.get("sql_id", "UNKNOWN"),
            "llm_narrative": response_text,
            "offline_structured_findings": offline_findings
        }

    def _build_prompt_payload(self, data: Dict[str, Any], offline_findings: Dict[str, Any]) -> str:
        return f"""# Oracle Slow SQL Diagnostic Telemetry
SQL_ID: {data.get('sql_id', 'UNKNOWN')}

## SQL Text
```sql
{data.get('sql_text', 'N/A')}
```

## Available Plan Hash Values (PHVs) & Historical Telemetry
{json.dumps(data.get('phv_metrics', []), indent=2)}

## SQL Profiles & SQL Plan Baselines
Profiles: {json.dumps(data.get('profiles', []), indent=2)}
Baselines: {json.dumps(data.get('baselines', []), indent=2)}

## Table Statistics Freshness
{json.dumps(data.get('table_stats', []), indent=2)}

## Underlying Table Indexes
{json.dumps(data.get('indexes', []), indent=2)}

## Real-Time SQL Monitor Summary
{json.dumps(data.get('sql_monitor', {}), indent=2)}

## Execution Plan (DBMS_XPLAN)
Plan Hash Value: {data.get('execution_plan', {}).get('phv', 'N/A')}
Tables Identified: {', '.join(data.get('execution_plan', {}).get('tables_involved', []))}
Predicates: {json.dumps(data.get('execution_plan', {}).get('predicates', []), indent=2)}
Outline Data: {json.dumps(data.get('execution_plan', {}).get('outline_data', []), indent=2)}
Notes: {json.dumps(data.get('execution_plan', {}).get('notes', []), indent=2)}

## Local Rule Engine Diagnostic Clues
- Severity: {offline_findings.get('severity')}
- Detected Primary Cause: {offline_findings.get('primary_cause')}
- PHV Regression: {offline_findings.get('phv_analysis', {}).get('summary')}
- Stats Freshness: {offline_findings.get('stats_analysis', {}).get('summary')}
- Missing Index Clues: {offline_findings.get('index_analysis', {}).get('summary')}

Please synthesize a deep forensic DBA report with root cause analysis, regression explanation, index design validation, and copy-pasteable remediation.
"""

    async def _call_gemini(self, user_content: str) -> str:
        clean_model = self.model.strip().removeprefix("models/")
        # Auto-correct obsolete or typo model names
        if clean_model in ["gemini-pro-2.5", "gemini-2.5-pro", "gemini-pro"]:
            clean_model = "gemini-2.0-flash"

        fallback_models = []
        if clean_model != "gemini-1.5-flash":
            fallback_models.append("gemini-1.5-flash")
        if clean_model != "gemini-1.5-pro":
            fallback_models.append("gemini-1.5-pro")

        models_to_try = [clean_model] + fallback_models
        last_error = None
        fallback_used = None

        payload_template = {
            "system_instruction": {
                "parts": [{"text": ORACLE_DBA_SYSTEM_PROMPT}]
            },
            "contents": [
                {
                    "role": "user",
                    "parts": [{"text": user_content}]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "maxOutputTokens": 8192
            }
        }

        import asyncio

        async with httpx.AsyncClient(timeout=90.0) as client:
            for model_attempt in models_to_try:
                url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_attempt}:generateContent?key={self.api_key}"
                
                # Try up to 2 attempts per model for transient glitches
                for attempt in range(2):
                    try:
                        resp = await client.post(url, json=payload_template)
                        if resp.status_code == 200:
                            data = resp.json()
                            candidates = data.get("candidates", [])
                            if candidates and "content" in candidates[0]:
                                parts = candidates[0]["content"].get("parts", [])
                                text = "".join([p.get("text", "") for p in parts])
                                if fallback_used:
                                    prefix = (
                                        f"> [!NOTE]\n"
                                        f"> **Automatic Model Fallback Activated**: The requested model `{clean_model}` was temporarily "
                                        f"experiencing high demand (HTTP 503). Analysis was successfully completed using `{fallback_used}`.\n\n"
                                    )
                                    return prefix + text
                                return text
                            return "No response returned by Gemini."
                        
                        err_text = resp.text
                        last_error = f"Gemini API Error ({resp.status_code}): {err_text}"
                        
                        # If 503 (overloaded) or 429 (rate limit), wait briefly or try fallback
                        if resp.status_code in [503, 429]:
                            if attempt == 0:
                                await asyncio.sleep(1.5)
                                continue
                            else:
                                # Switch to next model in models_to_try
                                fallback_used = model_attempt
                                break
                        elif resp.status_code == 404:
                            # Model not found, break and try fallback immediately
                            break
                        else:
                            # 400 or other fatal error - don't retry same error
                            raise RuntimeError(last_error)

                    except httpx.RequestError as e:
                        last_error = f"Network error communicating with Gemini: {str(e)}"
                        if attempt == 0:
                            await asyncio.sleep(1.5)
                            continue
                        break

            # If all models in the fallback chain were exhausted
            raise RuntimeError(
                f"Gemini service was unavailable across tested endpoints. "
                f"Google returned: {last_error}. "
                f"Suggestion: Switch to 'gemini-1.5-flash' in the dropdown or use Local Offline Engine."
            )

    async def _call_anthropic(self, user_content: str) -> str:
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        }
        payload = {
            "model": self.model,
            "system": ORACLE_DBA_SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": user_content}],
            "max_tokens": 8192,
            "temperature": 0.2
        }
        async with httpx.AsyncClient(timeout=90.0) as client:
            resp = await client.post(url, json=payload, headers=headers)
            if resp.status_code != 200:
                raise RuntimeError(f"Anthropic API Error ({resp.status_code}): {resp.text}")
            data = resp.json()
            content = data.get("content", [])
            return "".join([c.get("text", "") for c in content if c.get("type") == "text"])

    async def _call_openai(self, user_content: str) -> str:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": ORACLE_DBA_SYSTEM_PROMPT},
                {"role": "user", "content": user_content}
            ],
            "temperature": 0.2
        }
        async with httpx.AsyncClient(timeout=90.0) as client:
            resp = await client.post(url, json=payload, headers=headers)
            if resp.status_code != 200:
                raise RuntimeError(f"OpenAI API Error ({resp.status_code}): {resp.text}")
            data = resp.json()
            choices = data.get("choices", [])
            if choices and "message" in choices[0]:
                return choices[0]["message"].get("content", "")
            return "No response returned by OpenAI."

    async def _call_grok(self, user_content: str) -> str:
        url = "https://api.x.ai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": ORACLE_DBA_SYSTEM_PROMPT},
                {"role": "user", "content": user_content}
            ],
            "temperature": 0.2
        }
        async with httpx.AsyncClient(timeout=90.0) as client:
            resp = await client.post(url, json=payload, headers=headers)
            if resp.status_code != 200:
                raise RuntimeError(f"xAI Grok API Error ({resp.status_code}): {resp.text}")
            data = resp.json()
            choices = data.get("choices", [])
            if choices and "message" in choices[0]:
                return choices[0]["message"].get("content", "")
            return "No response returned by Grok."

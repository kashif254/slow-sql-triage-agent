"""
Oracle Slow SQL Triage - Diagnostic Parser
Parses Oracle execution plans, master collector bundles, index snapshots,
SQL Monitor reports, SQL Profiles, and Plan Baselines.
"""

import re
from typing import Dict, List, Any, Optional

class OracleDiagnosticParser:
    """Parses raw text inputs or master diagnostic bundles into structured models."""

    @staticmethod
    def parse_bundle(bundle_text: str) -> Dict[str, Any]:
        """
        Splits and parses a master bundle containing multiple tagged sections.
        """
        sections = {}
        pattern = r"=== SECTION:\s*([A-Z0-9_]+)\s*===(.*?)(?=(?:=== SECTION:|$))"
        matches = re.findall(pattern, bundle_text, re.DOTALL)
        
        for name, content in matches:
            sections[name.strip()] = content.strip()

        result = {
            "sql_id": "",
            "sql_text": "",
            "profiles": [],
            "baselines": [],
            "phv_metrics": [],
            "table_stats": [],
            "indexes": [],
            "sql_monitor": {},
            "execution_plan": {},
            "raw_sections": sections
        }

        # 1. SQL Metadata
        meta_sec = sections.get("SQL_METADATA", "")
        sql_id_match = re.search(r"SQL_ID:\s*([a-z0-9]+)", meta_sec, re.IGNORECASE)
        if sql_id_match:
            result["sql_id"] = sql_id_match.group(1).strip()

        if "SQL_TEXT" in sections and sections["SQL_TEXT"]:
            result["sql_text"] = sections["SQL_TEXT"].strip()
        elif "--- SQL_TEXT ---" in meta_sec:
            sql_text_part = meta_sec.split("--- SQL_TEXT ---")[-1].strip()
            result["sql_text"] = sql_text_part

        # 2. Profiles & Baselines
        prof_sec = sections.get("SQL_PROFILES_AND_BASELINES", "")
        result["profiles"] = OracleDiagnosticParser._parse_sql_profiles(prof_sec)
        result["baselines"] = OracleDiagnosticParser._parse_sql_baselines(prof_sec)

        # 3. PHV Metrics
        phv_sec = sections.get("PHV_METRICS", "")
        result["phv_metrics"] = OracleDiagnosticParser._parse_phv_metrics(phv_sec)

        # 4. Table Stats Freshness
        stats_sec = sections.get("TABLE_STATS_FRESHNESS", "")
        result["table_stats"] = OracleDiagnosticParser._parse_table_stats(stats_sec)

        # 5. Table Indexes
        idx_sec = sections.get("TABLE_INDEXES", "")
        result["indexes"] = OracleDiagnosticParser._parse_indexes(idx_sec)

        # 6. SQL Monitor
        mon_sec = sections.get("SQL_MONITOR", "")
        result["sql_monitor"] = OracleDiagnosticParser._parse_sql_monitor(mon_sec)

        # 7. Execution Plan
        plan_sec = sections.get("EXECUTION_PLAN_ADVANCED", "")
        if not plan_sec and "EXECUTION_PLAN" in sections:
            plan_sec = sections.get("EXECUTION_PLAN", "")
        if "AWR PLANS" in sections:
            plan_sec += "\n--- AWR PLANS ---\n" + sections.get("AWR PLANS", "")
        result["execution_plan"] = OracleDiagnosticParser._parse_execution_plan(plan_sec)

        # Populate fallback SQL_ID or involved tables if missing
        if not result["sql_id"] and result["execution_plan"].get("sql_id"):
            result["sql_id"] = result["execution_plan"]["sql_id"]

        return result

    @staticmethod
    def _parse_sql_profiles(text: str) -> List[Dict[str, Any]]:
        profiles = []
        if not text or "no rows selected" in text.lower():
            return profiles
        for line in text.splitlines():
            line = line.strip()
            if not line or "---" in line or "NAME" in line:
                continue
            parts = re.split(r"\s{2,}", line)
            if len(parts) >= 3:
                profiles.append({
                    "name": parts[0],
                    "category": parts[1] if len(parts) > 1 else "DEFAULT",
                    "status": parts[2] if len(parts) > 2 else "ENABLED"
                })
        return profiles

    @staticmethod
    def _parse_sql_baselines(text: str) -> List[Dict[str, Any]]:
        baselines = []
        if not text or "no rows selected" in text.lower():
            return baselines
        
        in_baselines = False
        for line in text.splitlines():
            line = line.strip()
            if "--- SQL_PLAN_BASELINES ---" in line:
                in_baselines = True
                continue
            if not in_baselines or not line or "SQL_HANDLE" in line or line.startswith("---"):
                continue
            
            parts = re.split(r"\s{2,}|\s+", line)
            if len(parts) >= 6:
                baselines.append({
                    "sql_handle": parts[0],
                    "plan_name": parts[1],
                    "enabled": parts[2].upper(),
                    "accepted": parts[3].upper(),
                    "fixed": parts[4].upper(),
                    "reproduced": parts[5].upper()
                })
        return baselines

    @staticmethod
    def _parse_phv_metrics(text: str) -> List[Dict[str, Any]]:
        metrics = []
        seen_phvs = set()
        for line in text.splitlines():
            line = line.strip()
            if not line or "PLAN_HASH_VALUE" in line or line.startswith("---") or line.startswith("==="):
                continue
            parts = re.split(r"\s+", line)
            if len(parts) >= 4 and parts[0].isdigit():
                phv = parts[0]
                if phv in seen_phvs:
                    continue
                try:
                    # Expecting: PHV, child_cursors/execs, executions, avg_elapsed, etc.
                    # Handle flexible column lengths
                    execs = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else (int(parts[1]) if parts[1].isdigit() else 1)
                    ela = float(parts[3]) if len(parts) > 3 and _is_float(parts[3]) else (float(parts[2]) if _is_float(parts[2]) else 0.0)
                    cpu = float(parts[4]) if len(parts) > 4 and _is_float(parts[4]) else 0.0
                    buffer_gets = int(parts[5]) if len(parts) > 5 and parts[5].isdigit() else 0
                    disk_reads = int(parts[6]) if len(parts) > 6 and parts[6].isdigit() else 0
                    rows = int(parts[7]) if len(parts) > 7 and parts[7].isdigit() else 0

                    metrics.append({
                        "phv": phv,
                        "executions": execs,
                        "avg_elapsed_sec": ela,
                        "avg_cpu_sec": cpu,
                        "avg_buffer_gets": buffer_gets,
                        "avg_disk_reads": disk_reads,
                        "avg_rows": rows
                    })
                    seen_phvs.add(phv)
                except Exception:
                    continue
        return metrics

    @staticmethod
    def _parse_table_stats(text: str) -> List[Dict[str, Any]]:
        stats = []
        for line in text.splitlines():
            line = line.strip()
            if not line or "OWNER" in line or line.startswith("---") or "no rows" in line.lower():
                continue
            parts = re.split(r"\s+", line)
            if len(parts) >= 7:
                owner = parts[0]
                table_name = parts[1]
                num_rows = int(parts[2]) if parts[2].isdigit() else 0
                blocks = int(parts[3]) if parts[3].isdigit() else 0
                last_analyzed = parts[5] + " " + parts[6] if len(parts) > 6 else parts[5]
                stale_stats = "YES" if "YES" in line.upper() else "NO"
                stats.append({
                    "owner": owner,
                    "table_name": table_name,
                    "num_rows": num_rows,
                    "blocks": blocks,
                    "last_analyzed": last_analyzed,
                    "stale_stats": stale_stats
                })
        return stats

    @staticmethod
    def _parse_indexes(text: str) -> List[Dict[str, Any]]:
        indexes = []
        for line in text.splitlines():
            line = line.strip()
            if not line or "TABLE_OWNER" in line or line.startswith("---") or "no rows" in line.lower():
                continue
            
            parts = [p.strip() for p in re.split(r"\s{2,}|\t+", line) if p.strip()]
            if len(parts) >= 5:
                table_owner = parts[0]
                table_name = parts[1]
                index_name = parts[2]
                uniqueness = parts[3]
                status = parts[4] if len(parts) > 4 else "VALID"
                index_cols = parts[-1] if len(parts) > 5 else ""

                clustering_factor = 0
                num_rows = 0
                for token in re.findall(r"\b\d+\b", line):
                    val = int(token)
                    if val > 50 and clustering_factor == 0:
                        clustering_factor = val
                    elif val > 50:
                        num_rows = val

                indexes.append({
                    "table_owner": table_owner,
                    "table_name": table_name,
                    "index_name": index_name,
                    "uniqueness": "UNIQUE" if "UNIQUE" in uniqueness.upper() and "NONUNIQUE" not in uniqueness.upper() else "NONUNIQUE",
                    "status": "VALID" if "VALID" in status.upper() else "UNUSABLE",
                    "clustering_factor": clustering_factor,
                    "num_rows": num_rows,
                    "columns": index_cols
                })
            else:
                # Fallback for single spaces
                tokens = re.split(r"\s+", line)
                if len(tokens) >= 5:
                    indexes.append({
                        "table_owner": tokens[0],
                        "table_name": tokens[1],
                        "index_name": tokens[2],
                        "uniqueness": tokens[3],
                        "status": tokens[4],
                        "clustering_factor": 0,
                        "num_rows": 0,
                        "columns": " ".join(tokens[5:])
                    })
        return indexes

    @staticmethod
    def _parse_sql_monitor(text: str) -> Dict[str, Any]:
        result = {
            "duration": "",
            "status": "",
            "elapsed_time_sec": 0,
            "cpu_time_sec": 0,
            "buffer_gets": "",
            "hotspots": []
        }
        if not text:
            return result

        dur_match = re.search(r"Duration\s*:\s*([0-9a-zA-Z]+)", text)
        if dur_match:
            result["duration"] = dur_match.group(1)

        status_match = re.search(r"Status\s*:\s*([^\n\r]+)", text)
        if status_match:
            result["status"] = status_match.group(1).strip()

        # Parse Plan Monitoring Details lines
        # | Id | Operation | Name | Rows (Estim) | Cost | Time Active | Rows (Actual) | Activity (%) | Activity Detail |
        for line in text.splitlines():
            if not line.startswith("|") or "SELECT STATEMENT" in line or "Operation" in line or "===" in line or "---" in line:
                continue
            cols = [c.strip() for c in line.split("|") if c.strip()]
            if len(cols) >= 5 and cols[0].isdigit():
                op_id = int(cols[0])
                op_name = cols[1]
                obj_name = cols[2] if len(cols) > 2 else ""
                
                # Find activity pct
                activity_match = re.search(r"(\d+(?:\.\d+)?)\s*%", line)
                activity_pct = float(activity_match.group(1)) if activity_match else 0.0
                if activity_pct == 0.0:
                    for c in reversed(cols):
                        try:
                            val = float(c)
                            if 0.0 < val <= 100.0:
                                activity_pct = val
                                break
                        except ValueError:
                            pass

                if activity_pct > 10.0 or "FULL" in op_name.upper():
                    result["hotspots"].append({
                        "id": op_id,
                        "operation": op_name,
                        "object_name": obj_name,
                        "activity_pct": activity_pct,
                        "line_snippet": line.strip()
                    })

        # Sort hotspots by activity %
        result["hotspots"].sort(key=lambda x: x["activity_pct"], reverse=True)
        return result

    @staticmethod
    def _parse_execution_plan(text: str) -> Dict[str, Any]:
        result = {
            "phv": "",
            "tables_involved": set(),
            "operations": [],
            "predicates": [],
            "outline_data": [],
            "notes": []
        }
        if not text:
            return result

        # PHV extraction
        phv_match = re.search(r"Plan hash value:\s*(\d+)", text, re.IGNORECASE)
        if phv_match:
            result["phv"] = phv_match.group(1)

        lines = text.splitlines()
        in_plan_table = False
        in_predicates = False
        in_outline = False
        in_notes = False

        for line in lines:
            line_str = line.strip()
            
            # Check sections
            if "Predicate Information" in line_str:
                in_plan_table = False
                in_predicates = True
                in_outline = False
                in_notes = False
                continue
            elif "Outline Data" in line_str or "BEGIN_OUTLINE_DATA" in line_str:
                in_plan_table = False
                in_predicates = False
                in_outline = True
                in_notes = False
                continue
            elif "Note" in line_str and "---" not in line_str:
                in_plan_table = False
                in_predicates = False
                in_outline = False
                in_notes = True
                continue
            elif line_str.startswith("===") or (in_outline and "END_OUTLINE_DATA" in line_str):
                if in_outline and "END_OUTLINE_DATA" in line_str:
                    result["outline_data"].append("END_OUTLINE_DATA")
                in_outline = False
                continue

            # Parsing Plan Table
            if line_str.startswith("|") and ("Id" in line_str or "Operation" in line_str):
                in_plan_table = True
                continue
            
            if in_plan_table and line_str.startswith("|"):
                cols = [c.strip() for c in line.split("|") if c.strip()]
                if len(cols) >= 3:
                    # Clean operation ID (strip *)
                    clean_id = re.sub(r"[^\d]", "", cols[0])
                    if clean_id.isdigit():
                        op_id = int(clean_id)
                        operation = cols[1]
                        object_name = cols[2] if len(cols) > 2 else ""

                        # Extract table names
                        if any(k in operation.upper() for k in ["TABLE ACCESS", "INDEX", "PARTITION", "BITMAP"]):
                            if object_name and not object_name.isdigit() and object_name.upper() not in ["SELECT STATEMENT", "SORT"]:
                                # If it's a table access full, it's definitely a table
                                clean_table = object_name.split(".")[-1]
                                result["tables_involved"].add(clean_table)

                        result["operations"].append({
                            "id": op_id,
                            "operation": operation,
                            "name": object_name,
                            "raw_line": line_str
                        })

            # Parsing Predicates
            elif in_predicates:
                pred_match = re.match(r"\s*(\d+)\s*-\s*(access|filter)\((.*)\)", line_str, re.IGNORECASE)
                if pred_match:
                    result["predicates"].append({
                        "id": int(pred_match.group(1)),
                        "type": pred_match.group(2).lower(),
                        "predicate": pred_match.group(3)
                    })

            # Parsing Outline
            elif in_outline:
                cleaned_hint = line_str.strip("/*+").strip("*/").strip()
                if cleaned_hint and not cleaned_hint.startswith("--"):
                    result["outline_data"].append(cleaned_hint)

            # Parsing Notes
            elif in_notes:
                if line_str.startswith("-"):
                    result["notes"].append(line_str.lstrip("-").strip())

        # Convert set of tables to sorted list
        result["tables_involved"] = sorted(list(result["tables_involved"]))
        return result


def _is_float(val: str) -> bool:
    try:
        float(val)
        return True
    except ValueError:
        return False

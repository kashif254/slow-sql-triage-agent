"""
Oracle Slow SQL Triage - Local Offline Engine
Deterministic, air-gapped heuristic rule engine. Evaluates all 6 diagnostic
vectors without any LLM or external network connectivity.
"""

import re
from typing import Dict, List, Any

class LocalOfflineTriageEngine:
    """Executes deterministic Oracle DBA triage rules on parsed telemetry."""

    def __init__(self, diagnostic_data: Dict[str, Any]):
        self.data = diagnostic_data
        self.sql_id = diagnostic_data.get("sql_id", "UNKNOWN")
        self.sql_text = diagnostic_data.get("sql_text", "")
        self.plan = diagnostic_data.get("execution_plan", {})
        self.phvs = diagnostic_data.get("phv_metrics", [])
        self.baselines = diagnostic_data.get("baselines", [])
        self.profiles = diagnostic_data.get("profiles", [])
        self.stats = diagnostic_data.get("table_stats", [])
        self.indexes = diagnostic_data.get("indexes", [])
        self.monitor = diagnostic_data.get("sql_monitor", {})

    def run_triage(self) -> Dict[str, Any]:
        """Runs all diagnostic checks and synthesizes a comprehensive report."""
        phv_findings = self._analyze_phv_regression()
        baseline_findings = self._analyze_baselines_and_profiles()
        stats_findings = self._analyze_stats_freshness()
        monitor_findings = self._analyze_sql_monitor()
        plan_findings = self._analyze_execution_plan()
        index_findings = self._analyze_index_suitability()
        remediation = self._generate_prescriptive_actions(
            phv_findings, baseline_findings, stats_findings, index_findings
        )

        # Determine overall severity and primary root cause
        severity = "LOW"
        primary_cause = "No critical performance regression detected."

        if phv_findings.get("is_regressed") or stats_findings.get("has_stale_stats") or index_findings.get("missing_indexes"):
            severity = "CRITICAL" if phv_findings.get("degradation_factor", 1) > 10 else "HIGH"
            
            causes = []
            if stats_findings.get("has_stale_stats"):
                stale_tables = [s["table_name"] for s in stats_findings.get("stale_tables", [])]
                causes.append(f"Stale table statistics on {', '.join(stale_tables)}")
            if phv_findings.get("is_regressed"):
                causes.append(f"Plan flip from PHV {phv_findings.get('best_phv')} ({phv_findings.get('best_ela')}s) to PHV {phv_findings.get('worst_phv')} ({phv_findings.get('worst_ela')}s)")
            if baseline_findings.get("has_unreproduced_baseline"):
                causes.append("SQL Plan Baseline was NOT reproduced by the CBO")
            if index_findings.get("missing_indexes"):
                causes.append(f"Missing high-efficiency composite indexes on {len(index_findings['missing_indexes'])} table(s)")

            primary_cause = " | ".join(causes)

        return {
            "sql_id": self.sql_id,
            "engine_mode": "Local Offline Engine (Air-Gapped)",
            "severity": severity,
            "primary_cause": primary_cause,
            "phv_analysis": phv_findings,
            "baseline_analysis": baseline_findings,
            "stats_analysis": stats_findings,
            "monitor_analysis": monitor_findings,
            "plan_analysis": plan_findings,
            "index_analysis": index_findings,
            "remediation": remediation
        }

    def _analyze_phv_regression(self) -> Dict[str, Any]:
        """Compares available PHVs to detect plan flips and degradation factor."""
        if not self.phvs or len(self.phvs) < 1:
            return {
                "is_regressed": False,
                "summary": "Only one or no historical PHV records available.",
                "phvs": self.phvs
            }

        sorted_phvs = sorted(self.phvs, key=lambda x: x.get("avg_elapsed_sec", 0.0))
        best = sorted_phvs[0]
        worst = sorted_phvs[-1]

        best_ela = best.get("avg_elapsed_sec", 0.0)
        worst_ela = worst.get("avg_elapsed_sec", 0.0)
        deg_factor = (worst_ela / best_ela) if best_ela > 0 else 1.0

        best_buf = best.get("avg_buffer_gets", 0)
        worst_buf = worst.get("avg_buffer_gets", 0)
        buf_factor = (worst_buf / best_buf) if best_buf > 0 else 1.0

        is_regressed = len(self.phvs) > 1 and deg_factor > 2.0

        return {
            "is_regressed": is_regressed,
            "best_phv": best.get("phv"),
            "best_ela": best_ela,
            "best_buffer_gets": best_buf,
            "worst_phv": worst.get("phv"),
            "worst_ela": worst_ela,
            "worst_buffer_gets": worst_buf,
            "degradation_factor": round(deg_factor, 1),
            "buffer_factor": round(buf_factor, 1),
            "summary": (
                f"Severe Plan Flip detected: degraded PHV {worst.get('phv')} is "
                f"{round(deg_factor, 1)}x slower and consumes {round(buf_factor, 1)}x more buffer gets "
                f"than baseline PHV {best.get('phv')}."
                if is_regressed else "PHV metrics show stable execution performance."
            ),
            "all_phvs": sorted_phvs
        }

    def _analyze_baselines_and_profiles(self) -> Dict[str, Any]:
        """Examines SQL Profiles and Plan Baselines for drift or non-reproduction."""
        unreproduced = []
        for b in self.baselines:
            if b.get("accepted") == "YES" and b.get("reproduced") == "NO":
                unreproduced.append(b)

        # Check notes from execution plan
        plan_notes = self.plan.get("notes", [])
        for note in plan_notes:
            if "not reproduced" in note.lower():
                unreproduced.append({"note": note, "accepted": "YES", "reproduced": "NO"})

        has_unreproduced = len(unreproduced) > 0
        return {
            "has_baselines": len(self.baselines) > 0,
            "has_profiles": len(self.profiles) > 0,
            "has_unreproduced_baseline": has_unreproduced,
            "unreproduced_baselines": unreproduced,
            "profiles": self.profiles,
            "baselines": self.baselines,
            "summary": (
                f"ALERT: Accepted SQL Plan Baseline exists but failed to reproduce ({len(unreproduced)} baseline(s)). "
                "The CBO was forced to fall back to an unaccepted/unverified execution plan."
                if has_unreproduced else (
                    "Active SQL Profiles/Baselines are being honored or none are configured."
                )
            )
        }

    def _analyze_stats_freshness(self) -> Dict[str, Any]:
        """Inspects table statistics freshness and flags STALE_STATS."""
        stale_tables = []
        for s in self.stats:
            if s.get("stale_stats") == "YES":
                stale_tables.append(s)

        # Also check execution plan notes
        plan_notes = self.plan.get("notes", [])
        for note in plan_notes:
            if "stale" in note.lower():
                stale_tables.append({"table_name": note, "stale_stats": "YES"})

        has_stale = len(stale_tables) > 0
        return {
            "has_stale_stats": has_stale,
            "stale_tables": stale_tables,
            "all_stats": self.stats,
            "summary": (
                f"CRITICAL: {len(stale_tables)} table(s) have STALE statistics! "
                "The optimizer makes join order and access path decisions on outdated data volumes."
                if has_stale else "All involved table statistics are reported fresh."
            )
        }

    def _analyze_sql_monitor(self) -> Dict[str, Any]:
        """Identifies hotspot operations consuming the vast majority of active time."""
        hotspots = self.monitor.get("hotspots", [])
        top_hotspot = hotspots[0] if hotspots else None
        
        return {
            "duration": self.monitor.get("duration", "N/A"),
            "status": self.monitor.get("status", "N/A"),
            "top_hotspot": top_hotspot,
            "hotspots": hotspots,
            "summary": (
                f"SQL Monitor Hotspot: Step ID {top_hotspot['id']} ({top_hotspot['operation']} {top_hotspot['object_name']}) "
                f"consumed {top_hotspot['activity_pct']}% of total active database time."
                if top_hotspot else "No SQL Monitor execution breakdown recorded."
            )
        }

    def _analyze_execution_plan(self) -> Dict[str, Any]:
        """Scans the execution plan for known anti-patterns (FTS, Cartesians, Skew)."""
        ops = self.plan.get("operations", [])
        full_scans = []
        cartesian_joins = []

        for op in ops:
            raw = op.get("operation", "").upper()
            name = op.get("name", "")
            if "TABLE ACCESS FULL" in raw:
                full_scans.append({"id": op.get("id"), "table": name})
            if "CARTESIAN" in raw:
                cartesian_joins.append({"id": op.get("id"), "operation": raw})

        tables = self.plan.get("tables_involved", [])

        return {
            "tables_involved": tables,
            "full_table_scans": full_scans,
            "cartesian_joins": cartesian_joins,
            "outline_hints_count": len(self.plan.get("outline_data", [])),
            "summary": (
                f"Plan contains {len(full_scans)} Full Table Scan(s) on tables: {', '.join([f['table'] for f in full_scans])}."
                + (f" WARNING: {len(cartesian_joins)} Cartesian Join(s) detected!" if cartesian_joins else "")
            )
        }

    def _analyze_index_suitability(self) -> Dict[str, Any]:
        """
        Cross-references WHERE predicates against existing indexes.
        Validates index prefixing and identifies missing composite indexes.
        """
        predicates = self.plan.get("predicates", [])
        missing_indexes = []
        existing_by_table = {}

        for idx in self.indexes:
            tbl = idx.get("table_name", "").upper()
            existing_by_table.setdefault(tbl, []).append(idx)

        # Identify tables with Full Scans or Filter predicates
        ops = self.plan.get("operations", [])
        fts_tables = {op.get("name", "").upper(): op.get("id") for op in ops if "TABLE ACCESS FULL" in op.get("operation", "").upper()}

        # Map table stats to check row counts
        table_stats_map = {s.get("table_name", "").upper(): s for s in self.stats}

        for table_name, op_id in fts_tables.items():
            if not table_name:
                continue
            
            t_stats = table_stats_map.get(table_name, {})
            num_rows = t_stats.get("num_rows", 0)
            blocks = t_stats.get("blocks", 0)

            # Find filter predicates for this operation
            tbl_preds = [p for p in predicates if p.get("id") == op_id]
            filter_text = " ".join([p.get("predicate", "") for p in tbl_preds])

            # If small reference table with no filter predicates, full scan is optimal
            if not filter_text and num_rows > 0 and num_rows <= 1000 and blocks <= 50:
                continue

            equality_cols = []
            range_cols = []

            # Match columns like "TAB"."COL" or COL =
            eq_matches = re.findall(r'"?[A-Za-z0-9_]+"?"?\.?"?([A-Za-z0-9_]+)"?\s*=\s*(?:\'[^\']*\'|\d+)', filter_text)
            for col in eq_matches:
                if col.upper() not in equality_cols:
                    equality_cols.append(col.upper())

            range_matches = re.findall(r'"?[A-Za-z0-9_]+"?"?\.?"?([A-Za-z0-9_]+)"?\s*(?:>=|<=|>|<|BETWEEN|LIKE)', filter_text)
            for col in range_matches:
                if col.upper() not in range_cols and col.upper() not in equality_cols:
                    range_cols.append(col.upper())

            # Specific join columns matching this table
            join_cols = []
            for p in predicates:
                if p.get("type") == "access" and "=" in p.get("predicate", ""):
                    for token in re.findall(r'"?[A-Za-z0-9_]+"?"?\.?"?([A-Za-z0-9_]+)"?', p.get("predicate", "")):
                        token_u = token.upper()
                        # Attribute ID to relevant table
                        if (table_name.startswith(token_u[:4]) or 
                            ("CUST" in table_name and "CUST" in token_u) or
                            ("PROD" in table_name and "PROD" in token_u) or
                            ("CHANNEL" in table_name and "CHANNEL" in token_u) or
                            ("SALE" in table_name and "TIME" in token_u)):
                            if token_u not in equality_cols and token_u not in range_cols and token_u not in join_cols:
                                join_cols.append(token_u)

            # Candidate index columns: Equality -> Range -> Join
            recommended_cols = equality_cols + range_cols + join_cols
            if not recommended_cols:
                continue

            # Compare against existing indexes
            curr_indexes = existing_by_table.get(table_name, [])
            match_found = False
            for idx in curr_indexes:
                idx_cols = idx.get("columns", "").upper()
                if equality_cols and equality_cols[0] in idx_cols:
                    match_found = True
                    break
                elif not equality_cols and recommended_cols and recommended_cols[0] in idx_cols:
                    match_found = True
                    break

            if not match_found and recommended_cols:
                index_name = f"IDX_{table_name}_TRIAGE"
                ddl = f"CREATE INDEX SH.{index_name} ON SH.{table_name} ({', '.join(recommended_cols)}) ONLINE COMPUTE STATISTICS;"
                missing_indexes.append({
                    "table_name": table_name,
                    "existing_indexes": curr_indexes,
                    "recommended_columns": recommended_cols,
                    "equality_columns": equality_cols,
                    "range_columns": range_cols,
                    "reason": f"Table undergoes Full Scan because existing index {', '.join([i['index_name'] for i in curr_indexes]) or 'NONE'} lacks leading filter column '{equality_cols[0] if equality_cols else recommended_cols[0]}'.",
                    "ddl": ddl
                })

        return {
            "missing_indexes": missing_indexes,
            "existing_indexes": self.indexes,
            "summary": (
                f"Identified {len(missing_indexes)} table(s) requiring new composite indexes to eliminate Full Table Scans."
                if missing_indexes else "Existing indexes provide adequate leading column coverage."
            )
        }

    def _generate_prescriptive_actions(
        self, phv_f: Dict[str, Any], base_f: Dict[str, Any], stats_f: Dict[str, Any], idx_f: Dict[str, Any]
    ) -> List[Dict[str, str]]:
        """Generates concrete, copy-pasteable DBA commands to fix the issues."""
        actions = []

        # 1. Stale Statistics Fix
        if stats_f.get("has_stale_stats"):
            for s in stats_f.get("stale_tables", []):
                tbl = s.get("table_name", "").replace('"', '').strip()
                owner = s.get("owner", "SH")
                actions.append({
                    "category": "Immediate Fix: Refresh Optimizer Statistics",
                    "description": f"Gather fresh stats for {owner}.{tbl} to correct cardinality misestimates (E-Rows vs A-Rows).",
                    "command": f"EXEC DBMS_STATS.GATHER_TABLE_STATS(ownname => '{owner}', tabname => '{tbl}', estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE, cascade => TRUE, method_opt => 'FOR ALL COLUMNS SIZE AUTO');"
                })

        # 2. Missing Index DDL
        for mi in idx_f.get("missing_indexes", []):
            actions.append({
                "category": "Architectural Fix: Create Composite Index",
                "description": f"Create targeted composite index on {mi['table_name']} to eliminate Full Table Scan.",
                "command": mi["ddl"]
            })

        # 3. SQL Plan Baseline Fix
        if base_f.get("has_unreproduced_baseline") and phv_f.get("best_phv"):
            best_phv = phv_f.get("best_phv")
            actions.append({
                "category": "Plan Stability Fix: Re-baseline to Good PHV",
                "description": f"Force plan stability by loading good PHV {best_phv} into SPM (SQL Plan Management).",
                "command": f"""DECLARE
  l_plans_loaded PLS_INTEGER;
BEGIN
  l_plans_loaded := DBMS_SPM.LOAD_PLANS_FROM_CURSOR_CACHE(
    sql_id => '{self.sql_id}',
    plan_hash_value => {best_phv},
    fixed => 'YES',
    enabled => 'YES'
  );
  DBMS_OUTPUT.PUT_LINE('Plans loaded: ' || l_plans_loaded);
END;
/"""
            })

        # 4. Optimizer Hint Recommendation
        if phv_f.get("best_phv"):
            actions.append({
                "category": "Workaround: Code Hinting",
                "description": "If DDL cannot be deployed immediately, apply optimizer hints to bypass the bad hash join.",
                "command": "/*+ LEADING(c s p ch) INDEX(c) USE_NL(s) */"
            })

        return actions

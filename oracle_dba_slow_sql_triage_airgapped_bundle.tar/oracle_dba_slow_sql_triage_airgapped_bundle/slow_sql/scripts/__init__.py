"""
Oracle Slow SQL Triage Scripts
"""

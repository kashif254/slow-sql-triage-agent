"""
Oracle Slow SQL Triage - Realistic Production Sample Data
Scenario: Overnight ETL caused STALE_STATS on CUSTOMERS table, leading to Plan Flip
from PHV 1842957301 (0.14s) to PHV 3958204910 (43.85s), missing composite index,
and a non-reproduced SQL Plan Baseline.
"""

SAMPLE_BUNDLE_TEXT = """=== SECTION: SQL_METADATA ===
SQL_ID: f82km90qxzv8a

SQL_ID        CHILD_NUMBER PLAN_HASH_VALUE EXECUTIONS AVG_ELA_SEC AVG_CPU_SEC AVG_BUFFER_GETS PARSING_SCHEMA_NAME MODULE ACTION
------------- ------------ --------------- ---------- ----------- ----------- --------------- ------------------- ------ ------
f82km90qxzv8a            0      3958204910        125     43.8520     38.1200          890450 SH_FINANCE          REP_SRV MONTHLY_BATCH

--- SQL_TEXT ---
SELECT /*+ MONITOR */
       c.cust_id, c.cust_last_name, c.cust_first_name,
       p.prod_name, ch.channel_desc,
       SUM(s.amount_sold) AS total_sales,
       COUNT(s.prod_id) AS items_purchased
FROM sh.sales s
JOIN sh.customers c ON s.cust_id = c.cust_id
JOIN sh.products p ON s.prod_id = p.prod_id
JOIN sh.channels ch ON s.channel_id = ch.channel_id
WHERE c.cust_state_province = 'CA'
  AND c.cust_credit_limit >= 50000
  AND s.time_id >= DATE '2026-01-01'
GROUP BY c.cust_id, c.cust_last_name, c.cust_first_name, p.prod_name, ch.channel_desc
ORDER BY total_sales DESC;

=== SECTION: SQL_PROFILES_AND_BASELINES ===
--- SQL_PROFILES ---
no rows selected

--- SQL_PLAN_BASELINES ---
SQL_HANDLE                     PLAN_NAME                      ENABLED ACCEPTED FIXED REPRODUCED AUTOPURGE CREATED             LAST_MODIFIED
------------------------------ ------------------------------ ------- -------- ----- ---------- --------- ------------------- -------------------
SQL_7a8b9c0d1e2f3a4b           SQL_PLAN_f82km90qxzv8a_good    YES     YES      NO    NO         YES       2026-02-10 14:20:00 2026-09-14 02:00:00

=== SECTION: PHV_METRICS ===
--- V$SQL PHV SUMMARY ---
PLAN_HASH_VALUE CHILD_CURSORS TOTAL_EXECUTIONS AVG_ELAPSED_SEC AVG_CPU_SEC AVG_BUFFER_GETS AVG_DISK_READS AVG_ROWS_PROCESSED FIRST_LOAD          LAST_ACTIVE
--------------- ------------- ---------------- --------------- ----------- --------------- -------------- ------------------ ------------------- -------------------
3958204910                  1              125         43.8520     38.1200          890450          48920               5210 2026-09-15/04:15:00 2026-09-15/21:40:12
1842957301                  0             1450          0.1420      0.1200            1420             12               5210 2026-08-01/10:00:00 2026-09-14/23:59:00

--- AWR HISTORICAL PHV SUMMARY ---
PLAN_HASH_VALUE TOTAL_EXECUTIONS AVG_ELAPSED_SEC AVG_CPU_SEC AVG_BUFFER_GETS AVG_DISK_READS AVG_ROWS_PROCESSED EARLIEST_SNAP       LATEST_SNAP
--------------- ---------------- --------------- ----------- --------------- -------------- ------------------ ------------------- -------------------
3958204910                   125         43.8520     38.1200          890450          48920               5210 2026-09-15 04:00:00 2026-09-15 22:00:00
1842957301                  8920          0.1380      0.1150            1390             10               5210 2026-08-01 00:00:00 2026-09-14 23:00:00

=== SECTION: TABLE_STATS_FRESHNESS ===
OWNER      TABLE_NAME             NUM_ROWS     BLOCKS AVG_ROW_LEN LAST_ANALYZED       SAMPLE_SIZE STALE_STATS USER_STATS
---------- -------------------- ---------- ---------- ----------- ------------------- ----------- ----------- ----------
SH         CUSTOMERS                  1200         45         180 2025-11-12 02:00:00        1200 YES         NO
SH         SALES                   9188432     104520          65 2026-09-14 22:00:00     9188432 NO          NO
SH         PRODUCTS                   2500         80         210 2026-09-14 22:00:00        2500 NO          NO
SH         CHANNELS                      5          2          40 2026-09-14 22:00:00           5 NO          NO

=== SECTION: TABLE_INDEXES ===
TABLE_OWNER TABLE_NAME      INDEX_NAME                UNIQUENES STATUS   CLUSTERING_FACTOR   NUM_ROWS BLEVEL LEAF_BLOCKS LAST_ANALYZED       INDEX_COLUMNS
----------- --------------- ------------------------- --------- -------- ----------------- ---------- ------ ----------- ------------------- -----------------------------------------
SH          CUSTOMERS       CUSTOMERS_PK              UNIQUE    VALID                 1180       1200      1           4 2025-11-12 02:00:00 CUST_ID (ASC)
SH          SALES           SALES_TIME_BIX            NONUNIQUE VALID                45210    9188432      2       12500 2026-09-14 22:00:00 TIME_ID (ASC)
SH          SALES           SALES_CUST_BIX            NONUNIQUE VALID                89120    9188432      2       14200 2026-09-14 22:00:00 CUST_ID (ASC)
SH          PRODUCTS        PRODUCTS_PK               UNIQUE    VALID                   75       2500      1           8 2026-09-14 22:00:00 PROD_ID (ASC)
SH          CHANNELS        CHANNELS_PK               UNIQUE    VALID                    2          5      0           1 2026-09-14 22:00:00 CHANNEL_ID (ASC)

=== SECTION: SQL_MONITOR ===
========================================================================================================================================================================
| SQL Monitoring Report for SQL_ID: f82km90qxzv8a                                                                                                                      |
========================================================================================================================================================================
Global Information
------------------------------
 Status              :  DONE (ALL ROWS)
 Instance ID         :  1
 Session             :  REP_USER (142:38912)
 SQL ID              :  f82km90qxzv8a
 SQL Execution ID    :  16777216
 Plan Hash Value     :  3958204910
 Duration            :  44s
 First Refresh Time  :  09/15/2026 21:39:28
 Last Refresh Time   :  09/15/2026 21:40:12

Global Stats
===================================================================================================
| Elapsed |   Cpu   |    IO    | Application | Fetch | Buffer | Read | Read  | Write | Write | Cell |
| Time(s) | Time(s) | Waits(s) |  Waits(s)   | Calls |  Gets  | Reqs | Bytes | Reqs  | Bytes | Offl |
===================================================================================================
|      44 |      38 |     5.85 |        0.00 |     1 |   890K | 3120 | 382MB |     0 |   0MB |  0%  |
===================================================================================================

SQL Plan Monitoring Details (Plan Hash Value=3958204910)
========================================================================================================================================================================
| Id |                Operation                |     Name     |  Rows   | Cost  |   Time    | Start | Execs |   Rows   | Read | Read  | Mem | Activity | Activity Detail |
|    |                                         |              | (Estim) |       | Active(s) | Active|       | (Actual) | Reqs | Bytes |     |   (%)    |   (# samples)   |
========================================================================================================================================================================
|  0 | SELECT STATEMENT                        |              |         |       |        43 |    +1 |     1 |     5210 |      |       |     |          |                 |
|  1 |  SORT ORDER BY                          |              |    5210 | 89120 |         2 |   +42 |     1 |     5210 |      |       |  2M |     4.55 | Cpu (2)         |
|  2 |   HASH GROUP BY                         |              |    5210 | 89120 |         4 |   +40 |     1 |     5210 |      |       | 16M |     9.09 | Cpu (4)         |
|  3 |    HASH JOIN                            |              |    5210 | 89085 |         6 |   +38 |     1 |    18450 |      |       |  4M |     4.55 | Cpu (2)         |
|  4 |     TABLE ACCESS FULL                   | CHANNELS     |       5 |     3 |         1 |    +1 |     1 |        5 |      |       |     |          |                 |
|  5 |     HASH JOIN                           |              |    5210 | 89082 |        10 |   +34 |     1 |    18450 |      |       |  8M |     9.09 | Cpu (4)         |
|  6 |      TABLE ACCESS FULL                  | PRODUCTS     |    2500 |    12 |         1 |    +1 |     1 |     2500 |      |       |     |          |                 |
|  7 |      HASH JOIN                          |              |    5210 | 89070 |        42 |    +2 |     1 |    18450 |      |       | 42M |    18.18 | Cpu (8)         |
|  8 |       TABLE ACCESS FULL                 | CUSTOMERS    |    1200 | 14500 |        41 |    +2 |     1 |     2.4M | 2800 | 340MB |     |    45.45 | db file scat (20)
|  9 |       PARTITION RANGE ITERATOR          |              |   45200 | 74500 |        14 |   +30 |     1 |   120000 |      |       |     |          |                 |
| 10 |        BITMAP CONVERSION TO ROWIDS      |              |   45200 | 74500 |        14 |   +30 |     1 |   120000 |      |       |     |          |                 |
| 11 |         BITMAP INDEX RANGE SCAN         | SALES_TIME_BIX |        |       |         8 |   +30 |     1 |       18 |  320 |  42MB |     |     9.09 | Cpu (4)         |
========================================================================================================================================================================

=== SECTION: EXECUTION_PLAN_ADVANCED ===
Plan hash value: 3958204910

--------------------------------------------------------------------------------------------------------------------------------------
| Id  | Operation                           | Name           | Starts | E-Rows | A-Rows |   A-Time   | Buffers | Reads  | Starts |
--------------------------------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT                    |                |      1 |        |   5210 |00:00:43.85 |     890K|  48920 |      1 |
|   1 |  SORT ORDER BY                      |                |      1 |   5210 |   5210 |00:00:43.85 |     890K|  48920 |      1 |
|   2 |   HASH GROUP BY                     |                |      1 |   5210 |   5210 |00:00:43.81 |     890K|  48920 |      1 |
|*  3 |    HASH JOIN                        |                |      1 |   5210 |  18450 |00:00:43.72 |     890K|  48920 |      1 |
|   4 |     TABLE ACCESS FULL               | CHANNELS       |      1 |      5 |      5 |00:00:00.01 |       7 |      0 |      1 |
|*  5 |     HASH JOIN                       |                |      1 |   5210 |  18450 |00:00:43.70 |     890K|  48920 |      1 |
|   6 |      TABLE ACCESS FULL              | PRODUCTS       |      1 |   2500 |   2500 |00:00:00.02 |      82 |      0 |      1 |
|*  7 |      HASH JOIN                      |                |      1 |   5210 |  18450 |00:00:43.68 |     890K|  48920 |      1 |
|*  8 |       TABLE ACCESS FULL             | CUSTOMERS      |      1 |   1200 |   2.4M |00:00:32.40 |    14500 |  28000 |      1 |
|   9 |       PARTITION RANGE ITERATOR      |                |      1 |  45200 | 120000 |00:00:11.20 |     875K|  20920 |      1 |
|  10 |        BITMAP CONVERSION TO ROWIDS  |                |      1 |  45200 | 120000 |00:00:10.80 |     875K|  20920 |      1 |
|* 11 |         BITMAP INDEX RANGE SCAN     | SALES_TIME_BIX |      1 |        |     18 |00:00:02.10 |    1200 |    320 |      1 |
--------------------------------------------------------------------------------------------------------------------------------------

Predicate Information (identified by operation id):
---------------------------------------------------
   3 - access("S"."CHANNEL_ID"="CH"."CHANNEL_ID")
   5 - access("S"."PROD_ID"="P"."PROD_ID")
   7 - access("S"."CUST_ID"="C"."CUST_ID")
   8 - filter(("C"."CUST_STATE_PROVINCE"='CA' AND "C"."CUST_CREDIT_LIMIT">=50000))
  11 - access("S"."TIME_ID">=TO_DATE(' 2026-01-01 00:00:00', 'syyyy-mm-dd hh24:mi:ss'))

Outline Data
-------------
  /*+
      BEGIN_OUTLINE_DATA
      IGNORE_OPTIM_EMBEDDED_HINTS
      OPTIMIZER_FEATURES_ENABLE('19.1.0')
      DB_VERSION_CACHE('19.1.0')
      ALL_ROWS
      OUTLINE_LEAF(@"SEL$1")
      FULL(@"SEL$1" "CH"@"SEL$1")
      FULL(@"SEL$1" "P"@"SEL$1")
      FULL(@"SEL$1" "C"@"SEL$1")
      INDEX_COMBINE(@"SEL$1" "S"@"SEL$1")
      LEADING(@"SEL$1" "CH"@"SEL$1" "P"@"SEL$1" "C"@"SEL$1" "S"@"SEL$1")
      USE_HASH(@"SEL$1" "P"@"SEL$1")
      USE_HASH(@"SEL$1" "C"@"SEL$1")
      USE_HASH(@"SEL$1" "S"@"SEL$1")
      USE_HASH_AGGREGATION(@"SEL$1")
      END_OUTLINE_DATA
  */

Note
-----
   - SQL plan baseline "SQL_PLAN_f82km90qxzv8a_good" used for this statement was NOT reproduced
   - Statistics for table "SH"."CUSTOMERS" are STALE

=== SECTION: END ===
"""

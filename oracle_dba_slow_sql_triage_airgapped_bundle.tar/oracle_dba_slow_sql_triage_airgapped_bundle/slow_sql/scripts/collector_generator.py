"""
ORACLE DBA "Slow SQL" Triage Agent - Oracle Data Collector Script Generator
Generates the user's verified, working Oracle SQL script (slow_sql_collector.sql).
"""

def generate_collector_sql(target_sql_id: str = "") -> str:
    """
    Returns the battle-tested, verified collector SQL script.
    Uses the provided target_sql_id if specified, or defaults to '8t30yju1v55mn'.
    """
    effective_sql_id = target_sql_id.strip() if target_sql_id else "8t30yju1v55mn"

    return f"""-- ====================================================================
-- ORACLE DBA "Slow SQL" Triage Diagnostic Collector
-- Generated for ORACLE DBA "Slow SQL" Triage Agent
-- Compatible with Oracle 11g, 12c, 18c, 19c, 21c, 23ai
-- Usage: @slow_sql_collector.sql [SQL_ID]
-- Output: slow_sql_<SQL_ID>_bundle.txt
-- ====================================================================

SET ECHO OFF
SET FEEDBACK OFF
SET HEADING ON
SET UNDERLINE OFF
SET VERIFY OFF
SET SQLBLANKLINES ON
SET LINESIZE 4000
SET PAGESIZE 50000
SET TRIMSPOOL ON
SET TERMOUT ON
SET SERVEROUTPUT ON SIZE UNLIMITED
SET LONG 2000000
SET LONGCHUNKSIZE 2000000
SET TAB OFF
WHENEVER SQLERROR CONTINUE
WHENEVER OSERROR CONTINUE

DEFINE v_sql_id = '{effective_sql_id}'

COLUMN spool_file NEW_VALUE v_spool_file NOPRINT
SELECT 'slow_sql_' || TRIM('&v_sql_id') || '_bundle.txt' AS spool_file FROM dual;

PROMPT
PROMPT [*] Collecting telemetry for SQL_ID: &v_sql_id
PROMPT [*] Output will be saved to: &v_spool_file
PROMPT

SPOOL &v_spool_file

PROMPT === SECTION: SQL_METADATA ===
PROMPT SQL_ID: &v_sql_id

SELECT sql_id, child_number, plan_hash_value, executions, ROUND(elapsed_time/NULLIF(executions,0)/1e6, 4) AS avg_ela_sec,ROUND(cpu_time/NULLIF(executions,0)/1e6, 4) AS avg_cpu_sec, ROUND(buffer_gets/NULLIF(executions,0), 0) AS avg_buffer_gets, parsing_schema_name, module, action FROM v$sql WHERE sql_id = TRIM('&v_sql_id') ORDER BY child_number;


PROMPT === SECTION: SQL_TEXT ===

SELECT sql_fulltext FROM v$sql WHERE sql_id = TRIM('&v_sql_id') AND ROWNUM = 1;

PROMPT === SECTION: SQL_PROFILES_AND_BASELINES ===

PROMPT --- SQL_PROFILES ---

SELECT name, category, status, created, last_modified, description FROM dba_sql_profiles WHERE name LIKE '%' || TRIM('&v_sql_id') || '%'    OR signature IN ( SELECT exact_matching_signature FROM v$sql WHERE sql_id = TRIM('&v_sql_id'));


PROMPT --- SQL_PLAN_BASELINES ---

SELECT sql_handle, plan_name, enabled, accepted, fixed, reproduced, autopurge, created, last_modified, last_executed FROM dba_sql_plan_baselines WHERE sql_handle LIKE '%' || TRIM('&v_sql_id') || '%' OR signature IN (SELECT exact_matching_signature FROM v$sql WHERE sql_id = TRIM('&v_sql_id'));

PROMPT === SECTION: PHV_METRICS ===

PROMPT --- V$SQL PHV SUMMARY ---

SELECT plan_hash_value, COUNT(DISTINCT child_number) AS child_cursors,  SUM(executions) AS total_executions, ROUND(SUM(elapsed_time)/NULLIF(SUM(executions),0)/1e6, 4) AS avg_elapsed_sec, ROUND(SUM(cpu_time)/NULLIF(SUM(executions),0)/1e6, 4) AS avg_cpu_sec, ROUND(SUM(buffer_gets)/NULLIF(SUM(executions),0), 0) AS avg_buffer_gets, ROUND(SUM(disk_reads)/NULLIF(SUM(executions),0), 0) AS avg_disk_reads,ROUND(SUM(rows_processed)/NULLIF(SUM(executions),0), 0) AS avg_rows_processed, MIN(first_load_time) AS first_load, MAX(last_active_time) AS last_active FROM v$sql WHERE sql_id = TRIM('&v_sql_id') GROUP BY plan_hash_value ORDER BY avg_elapsed_sec DESC;


PROMPT --- AWR HISTORICAL PHV SUMMARY ---

SELECT h.plan_hash_value, SUM(h.executions_delta) AS total_executions, ROUND(SUM(h.elapsed_time_delta)/NULLIF(SUM(h.executions_delta),0)/1e6, 4) AS avg_elapsed_sec, ROUND(SUM(h.cpu_time_delta)/NULLIF(SUM(h.executions_delta),0)/1e6, 4) AS avg_cpu_sec, ROUND(SUM(h.buffer_gets_delta)/NULLIF(SUM(h.executions_delta),0), 0) AS avg_buffer_gets, ROUND(SUM(disk_reads_delta)/NULLIF(SUM(executions),0), 0) AS avg_disk_reads, ROUND(SUM(rows_processed_delta)/NULLIF(SUM(executions),0), 0) AS avg_rows_processed, MIN(s.begin_interval_time) AS earliest_snap, MAX(s.end_interval_time) AS latest_snap fROM dba_hist_sqlstat h JOIN dba_hist_snapshot s ON h.snap_id = s.snap_id AND h.dbid = s.dbid  AND h.instance_number = s.instance_number WHERE h.sql_id = TRIM('&v_sql_id') GROUP BY h.plan_hash_value ORDER BY avg_elapsed_sec DESC;


PROMPT === SECTION: TABLE_STATS_FRESHNESS ===

SELECT t.owner, t.table_name, t.num_rows, t.blocks, t.avg_row_len,t.last_analyzed, t.sample_size, s.stale_stats, s.user_stats FROM all_tables t LEFT JOIN all_tab_statistics s  oN t.owner = s.owner AND t.table_name = s.table_name AND s.object_type = 'TABLE' WHERE (t.owner, t.table_name) IN (SELECT object_owner, object_name FROM v$sql_plan WHERE sql_id = TRIM('&v_sql_id') AND object_type LIKE '%TABLE%' AND object_owner IS NOT NULL  UNION SELECT table_owner, table_name FROM all_indexes WHERE (owner, index_name) IN (SELECT object_owner, object_name FROM v$sql_plan WHERE sql_id = TRIM('&v_sql_id') AND object_type LIKE '%INDEX%' AND object_owner IS NOT NULL)) ORDER BY t.owner, t.table_name;

PROMPT === SECTION: TABLE_INDEXES ===

SELECT i.table_owner, i.table_name, i.index_name, i.uniqueness, i.status, i.clustering_factor, i.num_rows, i.blevel, i.leaf_blocks, i.last_analyzed FROM all_indexes i WHERE (i.table_owner, i.table_name) IN (SELECT object_owner, object_name  FROM v$sql_plan WHERE sql_id = TRIM('&v_sql_id') AND object_type LIKE '%TABLE%' AND object_owner IS NOT NULL UNION SELECT table_owner, table_name FROM all_indexes WHERE (owner, index_name) IN (SELECT object_owner, object_name FROM v$sql_plan  WHERE sql_id = TRIM('&v_sql_id') AND object_type LIKE '%INDEX%' AND object_owner IS NOT NULL    )) ORDER BY i.table_owner, i.table_name, i.index_name;


PROMPT === SECTION: SQL_MONITOR ===

VAR v_rep CLOB
BEGIN
    :v_rep := 'SQL Monitor not executed.';
    BEGIN
        SELECT DBMS_SQLTUNE.REPORT_SQL_MONITOR(
                 sql_id => TRIM('&v_sql_id'), 
                 type   => 'TEXT',
                 report_level => 'ALL'
               ) INTO :v_rep FROM dual;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                SELECT DBMS_SQL_MONITOR.REPORT_SQL_MONITOR(
                         sql_id => TRIM('&v_sql_id'), 
                         type   => 'TEXT',
                         report_level => 'ALL'
                       ) INTO :v_rep FROM dual;
            EXCEPTION
                WHEN OTHERS THEN
                    :v_rep := 'SQL Monitor unavailable: ' || SQLERRM;
            END;
    END;
END;
/

SET HEADING OFF
PRINT v_rep

PROMPT === SECTION: EXECUTION_PLAN_ADVANCED ===
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(TRIM('&v_sql_id'), NULL, 'ADVANCED +OUTLINE +PREDICATE +ALLSTATS LAST'));

PROMPT === SECTION: AWR PLANS ===
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_AWR(TRIM('&v_sql_id'), NULL, NULL, 'ADVANCED +OUTLINE +PREDICATE'));

PROMPT === SECTION: END ===
SPOOL OFF
SET TERMOUT ON
SET HEADING ON
SET UNDERLINE ON
PROMPT [*] Diagnostic collection complete.
PROMPT [*] Results spooled to: &v_spool_file
PROMPT [*] Upload &v_spool_file to the ORACLE DBA "Slow SQL" Triage Agent.
"""

if __name__ == "__main__":
    import sys
    sql_id = sys.argv[1] if len(sys.argv) > 1 else ""
    print(generate_collector_sql(sql_id))

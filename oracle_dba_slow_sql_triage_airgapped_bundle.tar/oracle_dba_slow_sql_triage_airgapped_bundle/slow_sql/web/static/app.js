/**
 * Oracle Slow SQL Triage Agent - Interactive Frontend Logic
 */

let currentEngineMode = "local"; // "local" or "llm"
let detectedTables = [];

document.addEventListener("DOMContentLoaded", () => {
    initSettings();
    initToggle();
    initModelSelector();
    initTabs();
    initToolbar();
    initDragAndDrop();
    initApiKeyToggle();
});

// 1. Engine Toggle Switch
function initToggle() {
    const optLocal = document.getElementById("toggle-local");
    const optLlm = document.getElementById("toggle-llm");
    const llmPanel = document.getElementById("llm-config-panel");

    optLocal.addEventListener("click", () => {
        currentEngineMode = "local";
        optLocal.classList.add("active");
        optLlm.classList.remove("active");
        llmPanel.classList.add("hidden");
    });

    optLlm.addEventListener("click", () => {
        currentEngineMode = "llm";
        optLlm.classList.add("active");
        optLocal.classList.remove("active");
        llmPanel.classList.remove("hidden");
    });
}

// Supported models per provider
const PROVIDER_MODELS = {
    gemini: [
        { id: "gemini-2.0-flash", name: "Gemini 2.0 Flash (Fast & Highly Capable - Recommended)" },
        { id: "gemini-1.5-pro", name: "Gemini 1.5 Pro (Massive 2M Context - Deep Forensic)" },
        { id: "gemini-1.5-flash", name: "Gemini 1.5 Flash (Balanced & Fast)" },
        { id: "gemini-2.0-flash-thinking-exp-01-21", name: "Gemini 2.0 Flash Thinking (Reasoning Engine)" },
        { id: "gemini-2.0-pro-exp-02-05", name: "Gemini 2.0 Pro Experimental" },
        { id: "gemini-3.7-flash", name: "Gemini 3.7 Flash" },
        { id: "gemini-3.8-flash", name: "Gemini 3.8 Flash (High)" },
        { id: "custom", name: "Custom / Other Model Name..." }
    ],
    anthropic: [
        { id: "claude-3-7-sonnet-20250219", name: "Claude 3.7 Sonnet (Thinking / Flagship)" },
        { id: "claude-3-5-sonnet-20241022", name: "Claude 3.5 Sonnet" },
        { id: "claude-3-5-haiku-20241022", name: "Claude 3.5 Haiku" },
        { id: "custom", name: "Custom / Other Model Name..." }
    ],
    openai: [
        { id: "gpt-4o", name: "GPT-4o (Omni Flagship)" },
        { id: "o3-mini", name: "o3-mini (High Reasoning)" },
        { id: "o1", name: "o1 (Deep Reasoning)" },
        { id: "gpt-4o-mini", name: "GPT-4o Mini (Fast)" },
        { id: "custom", name: "Custom / Other Model Name..." }
    ],
    grok: [
        { id: "grok-2-latest", name: "Grok 2 (xAI Flagship)" },
        { id: "grok-beta", name: "Grok Beta" },
        { id: "custom", name: "Custom / Other Model Name..." }
    ]
};

function initModelSelector() {
    const providerSelect = document.getElementById("llm-provider");
    const modelSelect = document.getElementById("llm-model-select");
    const modelCustom = document.getElementById("llm-model-custom");

    function updateModels() {
        const provider = providerSelect.value;
        const models = PROVIDER_MODELS[provider] || [];
        modelSelect.innerHTML = "";
        models.forEach(m => {
            const opt = document.createElement("option");
            opt.value = m.id;
            opt.textContent = m.name;
            modelSelect.appendChild(opt);
        });
        checkCustomModel();
    }

    function checkCustomModel() {
        if (modelSelect.value === "custom") {
            modelCustom.classList.remove("hidden");
            modelCustom.focus();
        } else {
            modelCustom.classList.add("hidden");
        }
    }

    providerSelect.addEventListener("change", updateModels);
    modelSelect.addEventListener("change", checkCustomModel);

    // Initial population
    updateModels();
}

// 2. Input Mode Tabs (Master Bundle vs Individual Inputs)
function initTabs() {
    const tabBtns = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");

    tabBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            tabBtns.forEach(b => b.classList.remove("active"));
            tabContents.forEach(c => c.classList.remove("active"));

            btn.classList.add("active");
            const target = btn.getAttribute("data-tab");
            document.getElementById(target).classList.add("active");
        });
    });
}

// 3. Toolbar Actions
function initToolbar() {
    // Download Script Modal
    const btnDownloadScript = document.getElementById("btn-download-script");
    const modalScript = document.getElementById("modal-script");
    const modalClose = document.getElementById("modal-script-close");
    const btnDoDownload = document.getElementById("btn-do-download-script");
    const btnCopyScript = document.getElementById("btn-copy-script");
    const inputModalSqlId = document.getElementById("modal-sql-id");

    btnDownloadScript.addEventListener("click", () => {
        modalScript.classList.remove("hidden");
    });

    modalClose.addEventListener("click", () => {
        modalScript.classList.add("hidden");
    });

    btnDoDownload.addEventListener("click", () => {
        const sqlId = inputModalSqlId.value.trim();
        const url = `/api/collector-script?download=true${sqlId ? `&sql_id=${encodeURIComponent(sqlId)}` : ""}`;
        window.location.href = url;
        modalScript.classList.add("hidden");
    });

    btnCopyScript.addEventListener("click", async () => {
        const sqlId = inputModalSqlId.value.trim();
        const res = await fetch(`/api/collector-script?download=false${sqlId ? `&sql_id=${encodeURIComponent(sqlId)}` : ""}`);
        const text = await res.text();
        await navigator.clipboard.writeText(text);
        btnCopyScript.textContent = "Copied!";
        setTimeout(() => { btnCopyScript.textContent = "Copy to Clipboard"; }, 2000);
    });

    // Master Bundle File Upload
    const btnUploadBundle = document.getElementById("btn-upload-bundle");
    const fileInputBundle = document.getElementById("file-input-bundle");
    btnUploadBundle.addEventListener("click", () => fileInputBundle.click());
    fileInputBundle.addEventListener("change", (e) => handleFileSelect(e.target.files[0], "bundle_text"));

    // Individual Plan Upload
    const btnUploadPlan = document.getElementById("btn-upload-plan");
    const fileInputPlan = document.getElementById("file-input-plan");
    btnUploadPlan.addEventListener("click", () => fileInputPlan.click());
    fileInputPlan.addEventListener("change", (e) => {
        switchToIndividualTab();
        handleFileSelect(e.target.files[0], "execution_plan");
    });

    // Individual Index Snapshot Upload
    const btnUploadIndex = document.getElementById("btn-upload-index");
    const fileInputIndex = document.getElementById("file-input-index");
    btnUploadIndex.addEventListener("click", () => fileInputIndex.click());
    fileInputIndex.addEventListener("change", (e) => {
        switchToIndividualTab();
        handleFileSelect(e.target.files[0], "index_snapshot");
    });

    // Load Sample Scenario
    const btnLoadSample = document.getElementById("btn-load-sample");
    btnLoadSample.addEventListener("click", loadSampleData);

    // Run Triage Button
    const btnRunTriage = document.getElementById("btn-run-triage");
    btnRunTriage.addEventListener("click", runTriage);
}

function switchToIndividualTab() {
    document.querySelector('.tab-btn[data-tab="tab-individual"]').click();
}

// 4. File Drag & Drop
function initDragAndDrop() {
    const dropZone = document.getElementById("drag-drop-zone");
    const bundleTextarea = document.getElementById("input-bundle-text");

    ["dragenter", "dragover", "dragleave", "drop"].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ["dragenter", "dragover"].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.add("dragover"), false);
    });

    ["dragleave", "drop"].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.remove("dragover"), false);
    });

    dropZone.addEventListener("drop", (e) => {
        const file = e.dataTransfer.files[0];
        if (file) {
            handleFileSelect(file, "bundle_text");
        }
    });

    // Also parse on direct paste/input
    bundleTextarea.addEventListener("input", debounce(() => {
        const val = bundleTextarea.value.trim();
        if (val) parseTablesFromInput({ bundle_text: val });
    }, 600));

    document.getElementById("input-plan-text").addEventListener("input", debounce(() => {
        const val = document.getElementById("input-plan-text").value.trim();
        if (val) parseTablesFromInput({ execution_plan: val });
    }, 600));
}

function handleFileSelect(file, targetField) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        const content = e.target.result;
        if (targetField === "bundle_text") {
            document.getElementById("input-bundle-text").value = content;
            parseTablesFromInput({ bundle_text: content });
        } else if (targetField === "execution_plan") {
            document.getElementById("input-plan-text").value = content;
            parseTablesFromInput({ execution_plan: content });
        } else if (targetField === "index_snapshot") {
            document.getElementById("input-index-text").value = content;
        }
    };
    reader.readAsText(file);
}

// 5. Dynamic Table Detection Alert
async function parseTablesFromInput(payload) {
    try {
        const res = await fetch("/api/parse-plan", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        if (!res.ok) return;
        const data = await res.json();
        
        if (data.tables_involved && data.tables_involved.length > 0) {
            detectedTables = data.tables_involved;
            showTableAlert(detectedTables);
        } else {
            hideTableAlert();
        }
    } catch (err) {
        console.error("Error parsing tables:", err);
    }
}

function showTableAlert(tables) {
    const alertBanner = document.getElementById("alert-banner");
    const badgeGroup = document.getElementById("table-badge-group");
    badgeGroup.innerHTML = "";

    tables.forEach(t => {
        const span = document.createElement("span");
        span.className = "table-badge";
        span.textContent = t;
        badgeGroup.appendChild(span);
    });

    alertBanner.classList.remove("hidden");
}

function hideTableAlert() {
    document.getElementById("alert-banner").classList.add("hidden");
}

// 6. API Key Visibility Toggle
function initApiKeyToggle() {
    const btn = document.getElementById("btn-toggle-key-vis");
    const keyInput = document.getElementById("llm-api-key");
    btn.addEventListener("click", () => {
        if (keyInput.type === "password") {
            keyInput.type = "text";
            btn.textContent = "🔒";
        } else {
            keyInput.type = "password";
            btn.textContent = "👁️";
        }
    });
}

// 7. Load Sample Data
async function loadSampleData() {
    try {
        const res = await fetch("/api/sample-bundle");
        const data = await res.json();
        document.getElementById("input-bundle-text").value = data.bundle_text;
        
        // Switch to bundle tab
        document.querySelector('.tab-btn[data-tab="tab-bundle"]').click();

        // Trigger dynamic table discovery
        await parseTablesFromInput({ bundle_text: data.bundle_text });

        // Auto-run triage to give instant results
        runTriage();
    } catch (err) {
        alert("Failed to load sample data: " + err);
    }
}

// 8. Run Triage Analysis
async function runTriage() {
    const btnRun = document.getElementById("btn-run-triage");
    const resultsSec = document.getElementById("results-section");

    // Gather payload
    const activeTab = document.querySelector(".tab-content.active").id;
    const modelSelect = document.getElementById("llm-model-select");
    const modelCustom = document.getElementById("llm-model-custom");
    const chosenModel = modelSelect.value === "custom" ? (modelCustom.value.trim() || "gemini-2.0-flash") : modelSelect.value;

    let payload = {
        engine_mode: currentEngineMode,
        provider: document.getElementById("llm-provider").value,
        api_key: document.getElementById("llm-api-key").value.trim(),
        model: chosenModel
    };

    if (activeTab === "tab-bundle") {
        const bundleText = document.getElementById("input-bundle-text").value.trim();
        if (!bundleText) {
            alert("Please paste or upload a diagnostic bundle.");
            return;
        }
        payload.bundle_text = bundleText;
    } else {
        payload.sql_id = document.getElementById("input-sql-id").value.trim();
        payload.sql_text = document.getElementById("input-sql-text").value.trim();
        payload.execution_plan = document.getElementById("input-plan-text").value.trim();
        payload.index_snapshot = document.getElementById("input-index-text").value.trim();
        payload.phv_metrics = document.getElementById("input-phv-text").value.trim();
        payload.table_stats = document.getElementById("input-stats-text").value.trim();
        payload.profiles_baselines = document.getElementById("input-baselines-text").value.trim();
        payload.sql_monitor = document.getElementById("input-monitor-text").value.trim();

        if (!payload.execution_plan && !payload.sql_id) {
            alert("Please provide at least an Execution Plan or SQL_ID.");
            return;
        }
    }

    if (currentEngineMode === "llm" && !payload.api_key) {
        alert(`Please enter your ${payload.provider.toUpperCase()} API Key.`);
        document.getElementById("llm-api-key").focus();
        return;
    }

    // Set Loading State
    btnRun.innerHTML = `<span class="spinner"></span> Running Oracle Triage Analysis...`;
    btnRun.disabled = true;

    try {
        const res = await fetch("/api/triage", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const result = await res.json();
        if (!res.ok) {
            throw new Error(result.detail || "Triage execution failed.");
        }

        renderTriageResults(result);
        resultsSec.classList.remove("hidden");
        resultsSec.scrollIntoView({ behavior: "smooth" });
    } catch (err) {
        alert("Triage Error: " + err.message);
    } finally {
        btnRun.innerHTML = `🚀 Run Oracle Slow SQL Triage`;
        btnRun.disabled = false;
    }
}

// 9. Render Diagnostic Dashboard
function renderTriageResults(data) {
    const report = data.local_report;

    // A. Executive Summary Banner
    const banner = document.getElementById("result-summary-banner");
    banner.className = `summary-banner ${report.severity}`;
    
    document.getElementById("result-severity-badge").className = `badge badge-${report.severity.toLowerCase()}`;
    document.getElementById("result-severity-badge").textContent = `${report.severity} SEVERITY`;
    document.getElementById("result-engine-badge").textContent = data.engine_mode === "llm" ? `LLM: ${data.provider.toUpperCase()}` : "LOCAL OFFLINE";
    document.getElementById("result-sql-id").textContent = `SQL_ID: ${report.sql_id}`;
    document.getElementById("result-primary-cause").textContent = report.primary_cause;

    // B. PHV Regression Matrix
    const phvContainer = document.getElementById("result-phv-matrix");
    const phvData = report.phv_analysis;
    if (phvData && phvData.all_phvs && phvData.all_phvs.length > 0) {
        let phvHtml = `
            <p style="font-size:0.85rem; color:var(--text-secondary); margin-bottom:0.5rem;">${phvData.summary}</p>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Plan Hash Value</th>
                        <th>Status</th>
                        <th>Executions</th>
                        <th>Avg Elapsed (s)</th>
                        <th>Avg Buffer Gets</th>
                        <th>Avg Disk Reads</th>
                    </tr>
                </thead>
                <tbody>
        `;
        phvData.all_phvs.forEach(p => {
            const isBest = p.phv == phvData.best_phv;
            const isWorst = p.phv == phvData.worst_phv;
            const badgeClass = isBest ? "badge-low" : (isWorst ? "badge-critical" : "badge-high");
            const badgeLabel = isBest ? "BASELINE (BEST)" : (isWorst ? "DEGRADED (CURRENT)" : "HISTORICAL");
            phvHtml += `
                <tr>
                    <td style="font-family:var(--font-mono); font-weight:bold;">${p.phv}</td>
                    <td><span class="badge ${badgeClass}">${badgeLabel}</span></td>
                    <td>${p.executions.toLocaleString()}</td>
                    <td style="font-weight:bold; color:${isWorst ? '#ef4444' : '#10b981'};">${p.avg_elapsed_sec.toFixed(4)}s</td>
                    <td>${p.avg_buffer_gets.toLocaleString()}</td>
                    <td>${p.avg_disk_reads.toLocaleString()}</td>
                </tr>
            `;
        });
        phvHtml += `</tbody></table>`;
        phvContainer.innerHTML = phvHtml;
    } else {
        phvContainer.innerHTML = `<p style="color:var(--text-muted);">No historical PHV telemetry found.</p>`;
    }

    // C. Baselines & Profiles Health
    const baseContainer = document.getElementById("result-baselines-health");
    const baseData = report.baseline_analysis;
    baseContainer.innerHTML = `
        <p style="font-size:0.85rem; color:${baseData.has_unreproduced_baseline ? '#ef4444' : 'var(--text-secondary)'}; margin-bottom:0.5rem;">
            ${baseData.summary}
        </p>
    `;

    // D. Table Stats Freshness
    const statsContainer = document.getElementById("result-stats-freshness");
    const statsData = report.stats_analysis;
    if (statsData && statsData.all_stats && statsData.all_stats.length > 0) {
        let statsHtml = `
            <p style="font-size:0.85rem; color:${statsData.has_stale_stats ? '#ef4444' : 'var(--text-secondary)'}; margin-bottom:0.5rem;">
                ${statsData.summary}
            </p>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Table</th>
                        <th>Num Rows</th>
                        <th>Blocks</th>
                        <th>Last Analyzed</th>
                        <th>Stale Stats?</th>
                    </tr>
                </thead>
                <tbody>
        `;
        statsData.all_stats.forEach(s => {
            const isStale = s.stale_stats === "YES";
            statsHtml += `
                <tr>
                    <td style="font-family:var(--font-mono);">${s.owner ? s.owner + '.' : ''}${s.table_name}</td>
                    <td>${s.num_rows ? s.num_rows.toLocaleString() : 'N/A'}</td>
                    <td>${s.blocks ? s.blocks.toLocaleString() : 'N/A'}</td>
                    <td>${s.last_analyzed || 'N/A'}</td>
                    <td><span class="badge ${isStale ? 'badge-critical' : 'badge-low'}">${s.stale_stats}</span></td>
                </tr>
            `;
        });
        statsHtml += `</tbody></table>`;
        statsContainer.innerHTML = statsHtml;
    } else {
        statsContainer.innerHTML = `<p style="color:var(--text-muted);">No dictionary table statistics available.</p>`;
    }

    // E. SQL Monitor Hotspots
    const monContainer = document.getElementById("result-sql-monitor");
    const monData = report.monitor_analysis;
    if (monData && monData.top_hotspot) {
        monContainer.innerHTML = `
            <p style="font-size:0.85rem; margin-bottom:0.5rem; color:#f59e0b;">${monData.summary}</p>
            <div class="code-box">${escapeHtml(monData.top_hotspot.line_snippet)}</div>
        `;
    } else {
        monContainer.innerHTML = `<p style="color:var(--text-muted);">${monData.summary}</p>`;
    }

    // F. Index Deficiency & Recommended DDL
    const idxContainer = document.getElementById("result-index-recommendations");
    const idxData = report.index_analysis;
    if (idxData && idxData.missing_indexes && idxData.missing_indexes.length > 0) {
        let idxHtml = `<p style="font-size:0.85rem; color:var(--text-secondary); margin-bottom:0.5rem;">${idxData.summary}</p>`;
        idxData.missing_indexes.forEach((mi, i) => {
            idxHtml += `
                <div style="margin-top:1rem; padding:0.75rem; background:#111827; border-radius:6px;">
                    <div style="font-weight:600; font-size:0.9rem; color:#38bdf8;">Missing Index on: ${mi.table_name}</div>
                    <p style="font-size:0.8rem; color:var(--text-muted); margin-top:0.25rem;">${mi.reason}</p>
                    <div class="code-box">
                        <button class="btn-copy" onclick="copyCode(this)">Copy DDL</button>
                        <code>${escapeHtml(mi.ddl)}</code>
                    </div>
                </div>
            `;
        });
        idxContainer.innerHTML = idxHtml;
    } else {
        idxContainer.innerHTML = `<p style="color:#10b981;">${idxData.summary}</p>`;
    }

    // G. Prescriptive Actions
    const actContainer = document.getElementById("result-prescriptive-actions");
    if (report.remediation && report.remediation.length > 0) {
        let actHtml = "";
        report.remediation.forEach(act => {
            actHtml += `
                <div style="margin-bottom:1rem; padding:0.75rem; background:#111827; border-left:3px solid var(--accent-blue); border-radius:0 6px 6px 0;">
                    <div style="font-weight:600; font-size:0.85rem; color:#60a5fa;">${act.category}</div>
                    <p style="font-size:0.8rem; color:var(--text-secondary); margin:0.25rem 0;">${act.description}</p>
                    <div class="code-box">
                        <button class="btn-copy" onclick="copyCode(this)">Copy</button>
                        <code>${escapeHtml(act.command)}</code>
                    </div>
                </div>
            `;
        });
        actContainer.innerHTML = actHtml;
    } else {
        actContainer.innerHTML = `<p style="color:var(--text-muted);">No specific remediation required.</p>`;
    }

    // H. LLM Forensic Narrative Card (if available)
    const llmContainer = document.getElementById("result-llm-card");
    const llmNarrative = document.getElementById("result-llm-narrative");
    if (data.llm_narrative) {
        llmNarrative.innerHTML = renderMarkdown(data.llm_narrative);
        llmContainer.classList.remove("hidden");
    } else {
        llmContainer.classList.add("hidden");
    }
}

// Utility: Copy code box content
function copyCode(btn) {
    const code = btn.nextElementSibling.textContent;
    navigator.clipboard.writeText(code);
    btn.textContent = "Copied!";
    setTimeout(() => { btn.textContent = "Copy"; }, 2000);
}

// Simple Markdown Renderer
function renderMarkdown(md) {
    if (!md) return "";
    let html = escapeHtml(md);

    // Code blocks
    html = html.replace(/```([a-zA-Z]*)\n([\s\S]*?)```/g, (match, lang, code) => {
        return `<pre><code>${code}</code></pre>`;
    });

    // Inline code
    html = html.replace(/`([^`]+)`/g, "<code>$1</code>");

    // Headers
    html = html.replace(/^### (.*$)/gim, "<h3>$1</h3>");
    html = html.replace(/^## (.*$)/gim, "<h2>$1</h2>");
    html = html.replace(/^# (.*$)/gim, "<h1>$1</h1>");

    // Bold & italic
    html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    html = html.replace(/\*([^*]+)\*/g, "<em>$1</em>");

    // Line breaks
    html = html.replace(/\n\n/g, "<br><br>");

    return html;
}

function escapeHtml(str) {
    if (!str) return "";
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function debounce(func, wait) {
    let timeout;
    return function (...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

/* =========================================================================
   System Settings & Appearance Controller
   ========================================================================= */

let currentServerConfig = null;

function initSettings() {
    // 1. Elements
    const btnOpenSettings = document.getElementById("btn-open-settings");
    const modalSettings = document.getElementById("modal-settings");
    const modalClose = document.getElementById("modal-settings-close");
    const btnSave = document.getElementById("btn-save-settings");
    const btnReset = document.getElementById("btn-reset-settings");
    const jumpBoxBadge = document.getElementById("jump-box-badge");
    const jumpBoxLabel = document.getElementById("jump-box-label");
    const copyIcon = document.getElementById("jump-box-copy-icon");
    const btnModalCopy = document.getElementById("btn-modal-copy-url");
    const settingColleagueUrl = document.getElementById("setting-colleague-url");

    // 2. Load Server Configuration from /api/config
    fetch("/api/config")
        .then(res => res.json())
        .then(data => {
            currentServerConfig = data;
            const publicHost = data.public_host || "vbaw-spaces-mgt.itsso.gc.ca";
            const port = data.port || 8000;
            const colleagueUrl = data.colleague_url || `http://${publicHost}:${port}`;

            if (jumpBoxLabel) jumpBoxLabel.textContent = `${publicHost}:${port}`;
            if (settingColleagueUrl) settingColleagueUrl.textContent = colleagueUrl;

            const inputPublicHost = document.getElementById("setting-public-host");
            const inputPort = document.getElementById("setting-server-port");
            const selectBindHost = document.getElementById("setting-bind-host");

            if (inputPublicHost) inputPublicHost.value = publicHost;
            if (inputPort) inputPort.value = port;
            if (selectBindHost && data.config?.server?.bind_host) {
                selectBindHost.value = data.config.server.bind_host;
            }
        })
        .catch(err => {
            console.warn("Could not load /api/config:", err);
        });

    // 3. Copy Link Action
    function copyColleagueUrl(targetBtn, iconElem) {
        const url = settingColleagueUrl ? settingColleagueUrl.textContent : window.location.origin;
        navigator.clipboard.writeText(url).then(() => {
            const origText = targetBtn ? targetBtn.textContent : "";
            if (targetBtn) targetBtn.textContent = "✓ Copied!";
            if (iconElem) iconElem.textContent = "✓";
            setTimeout(() => {
                if (targetBtn) targetBtn.textContent = origText;
                if (iconElem) iconElem.textContent = "📋";
            }, 2000);
        }).catch(() => {
            alert(`Colleague URL: ${url}`);
        });
    }

    if (jumpBoxBadge) {
        jumpBoxBadge.addEventListener("click", () => copyColleagueUrl(null, copyIcon));
    }
    if (btnModalCopy) {
        btnModalCopy.addEventListener("click", () => copyColleagueUrl(btnModalCopy, null));
    }

    // 4. Modal Open/Close & Tab Switching
    if (btnOpenSettings && modalSettings) {
        btnOpenSettings.addEventListener("click", () => {
            modalSettings.classList.remove("hidden");
        });
    }

    if (modalClose && modalSettings) {
        modalClose.addEventListener("click", () => {
            modalSettings.classList.add("hidden");
        });
    }

    if (modalSettings) {
        modalSettings.addEventListener("click", (e) => {
            if (e.target === modalSettings) {
                modalSettings.classList.add("hidden");
            }
        });
    }

    // Settings Tab Switching
    const tabBtns = document.querySelectorAll(".settings-tab-btn");
    tabBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            const targetTab = btn.getAttribute("data-tab");
            tabBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");

            document.querySelectorAll(".settings-tab-pane").forEach(pane => {
                pane.classList.remove("active");
            });
            const activePane = document.getElementById(`tab-pane-${targetTab}`);
            if (activePane) activePane.classList.add("active");
        });
    });

    // 5. Theme & Appearance Management
    const themeCards = document.querySelectorAll(".theme-card");
    const customBgPicker = document.getElementById("custom-bg-picker");
    const btnApplyCustom = document.getElementById("btn-apply-custom-color");
    const customColorLabel = document.getElementById("custom-color-label");

    function applyTheme(themeName, customColor = null) {
        // Remove existing theme classes
        document.body.classList.remove("theme-dark", "theme-light", "theme-oled", "theme-slate", "theme-custom");

        // Clear inline custom styles if not custom
        if (themeName !== "custom") {
            document.body.style.removeProperty("--bg-primary");
            document.body.style.removeProperty("--bg-secondary");
            document.body.style.removeProperty("--bg-card");
            document.body.style.removeProperty("--bg-input");
            document.body.style.removeProperty("--text-primary");
            document.body.style.removeProperty("--text-secondary");
            document.body.style.removeProperty("--border-color");
            document.body.classList.add(`theme-${themeName}`);
        } else if (customColor) {
            document.body.classList.add("theme-custom");
            document.body.style.setProperty("--bg-primary", customColor);
            
            // Derive secondary and card colors
            const isLight = isColorLight(customColor);
            const secondaryColor = adjustColorBrightness(customColor, isLight ? -12 : 18);
            const cardColor = adjustColorBrightness(customColor, isLight ? -20 : 28);
            const inputColor = adjustColorBrightness(customColor, isLight ? -8 : 10);
            const borderColor = adjustColorBrightness(customColor, isLight ? -30 : 40);

            document.body.style.setProperty("--bg-secondary", secondaryColor);
            document.body.style.setProperty("--bg-card", cardColor);
            document.body.style.setProperty("--bg-input", inputColor);
            document.body.style.setProperty("--border-color", borderColor);
            document.body.style.setProperty("--text-primary", isLight ? "#0f172a" : "#f1f5f9");
            document.body.style.setProperty("--text-secondary", isLight ? "#334155" : "#94a3b8");
        }

        // Highlight active card
        themeCards.forEach(c => {
            if (c.getAttribute("data-theme") === themeName) {
                c.classList.add("active");
            } else {
                c.classList.remove("active");
            }
        });

        localStorage.setItem("slow_sql_theme", themeName);
        if (customColor) {
            localStorage.setItem("slow_sql_custom_color", customColor);
        }
    }

    // Bind Theme Card Clicks
    themeCards.forEach(card => {
        card.addEventListener("click", () => {
            const theme = card.getAttribute("data-theme");
            applyTheme(theme);
        });
    });

    // Custom Color Picker
    if (customBgPicker) {
        customBgPicker.addEventListener("input", (e) => {
            const color = e.target.value;
            if (customColorLabel) customColorLabel.textContent = `Custom: ${color.toUpperCase()}`;
        });
    }

    if (btnApplyCustom && customBgPicker) {
        btnApplyCustom.addEventListener("click", () => {
            const color = customBgPicker.value;
            themeCards.forEach(c => c.classList.remove("active"));
            applyTheme("custom", color);
        });
    }

    // Load initial theme from localStorage
    const savedTheme = localStorage.getItem("slow_sql_theme") || "dark";
    const savedCustomColor = localStorage.getItem("slow_sql_custom_color") || "#0b0f19";
    if (customBgPicker) customBgPicker.value = savedCustomColor;
    if (customColorLabel) customColorLabel.textContent = `Custom: ${savedCustomColor.toUpperCase()}`;
    applyTheme(savedTheme, savedTheme === "custom" ? savedCustomColor : null);

    // 6. Preferences & API Key Management
    const checkRememberKey = document.getElementById("setting-remember-key");
    const btnClearKey = document.getElementById("btn-clear-saved-key");
    const inputApiKey = document.getElementById("llm-api-key");
    const selectDefaultEngine = document.getElementById("setting-default-engine");
    const selectDegradation = document.getElementById("setting-degradation-threshold");
    const inputSchemaOwner = document.getElementById("setting-schema-owner");

    // Load saved preferences
    const isRememberKey = localStorage.getItem("slow_sql_remember_key") === "true";
    if (checkRememberKey) checkRememberKey.checked = isRememberKey;

    if (isRememberKey && inputApiKey) {
        const savedKey = localStorage.getItem("slow_sql_saved_api_key");
        if (savedKey) inputApiKey.value = savedKey;
    }

    const savedEngine = localStorage.getItem("slow_sql_default_engine");
    if (savedEngine && selectDefaultEngine) {
        selectDefaultEngine.value = savedEngine;
        // Apply to page
        const optLocal = document.getElementById("toggle-local");
        const optLlm = document.getElementById("toggle-llm");
        const llmPanel = document.getElementById("llm-config-panel");
        if (savedEngine === "llm" && optLlm && optLocal && llmPanel) {
            currentEngineMode = "llm";
            optLlm.classList.add("active");
            optLocal.classList.remove("active");
            llmPanel.classList.remove("hidden");
        }
    }

    const savedDeg = localStorage.getItem("slow_sql_degradation_threshold");
    if (savedDeg && selectDegradation) selectDegradation.value = savedDeg;

    const savedSchema = localStorage.getItem("slow_sql_schema_owner");
    if (savedSchema && inputSchemaOwner) inputSchemaOwner.value = savedSchema;

    // Clear saved key button
    if (btnClearKey) {
        btnClearKey.addEventListener("click", () => {
            localStorage.removeItem("slow_sql_saved_api_key");
            localStorage.removeItem("slow_sql_remember_key");
            if (checkRememberKey) checkRememberKey.checked = false;
            if (inputApiKey) inputApiKey.value = "";
            alert("Saved API key removed from browser storage.");
        });
    }

    // 7. Save & Apply Button
    if (btnSave) {
        btnSave.addEventListener("click", () => {
            // Save preferences
            if (selectDefaultEngine) {
                localStorage.setItem("slow_sql_default_engine", selectDefaultEngine.value);
            }
            if (selectDegradation) {
                localStorage.setItem("slow_sql_degradation_threshold", selectDegradation.value);
            }
            if (inputSchemaOwner) {
                localStorage.setItem("slow_sql_schema_owner", inputSchemaOwner.value);
            }

            // Save API key if enabled
            if (checkRememberKey && checkRememberKey.checked && inputApiKey && inputApiKey.value.trim()) {
                localStorage.setItem("slow_sql_remember_key", "true");
                localStorage.setItem("slow_sql_saved_api_key", inputApiKey.value.trim());
            } else if (checkRememberKey && !checkRememberKey.checked) {
                localStorage.removeItem("slow_sql_remember_key");
                localStorage.removeItem("slow_sql_saved_api_key");
            }

            // Save network config back to server
            const inputPublicHost = document.getElementById("setting-public-host");
            const inputPort = document.getElementById("setting-server-port");
            const selectBindHost = document.getElementById("setting-bind-host");

            const networkPayload = {
                server: {
                    public_host: inputPublicHost ? inputPublicHost.value.trim() : "vbaw-spaces-mgt.itsso.gc.ca",
                    port: inputPort ? parseInt(inputPort.value, 10) : 8000,
                    bind_host: selectBindHost ? selectBindHost.value : "0.0.0.0"
                },
                triage_defaults: {
                    default_engine: selectDefaultEngine ? selectDefaultEngine.value : "local",
                    degradation_threshold: selectDegradation ? parseFloat(selectDegradation.value) : 2.0,
                    default_schema_owner: inputSchemaOwner ? inputSchemaOwner.value.trim() : "SH"
                }
            };

            fetch("/api/config", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(networkPayload)
            }).then(res => res.json()).then(resp => {
                if (jumpBoxLabel) jumpBoxLabel.textContent = `${networkPayload.server.public_host}:${networkPayload.server.port}`;
                if (settingColleagueUrl) settingColleagueUrl.textContent = `http://${networkPayload.server.public_host}:${networkPayload.server.port}`;
                modalSettings.classList.add("hidden");
            }).catch(e => {
                console.warn("Could not save server config to config.json:", e);
                modalSettings.classList.add("hidden");
            });
        });
    }

    // 8. Reset to Defaults
    if (btnReset) {
        btnReset.addEventListener("click", () => {
            if (confirm("Reset appearance and preferences to factory defaults?")) {
                localStorage.removeItem("slow_sql_theme");
                localStorage.removeItem("slow_sql_custom_color");
                localStorage.removeItem("slow_sql_remember_key");
                localStorage.removeItem("slow_sql_saved_api_key");
                localStorage.removeItem("slow_sql_default_engine");
                localStorage.removeItem("slow_sql_degradation_threshold");
                localStorage.removeItem("slow_sql_schema_owner");
                applyTheme("dark");
                if (checkRememberKey) checkRememberKey.checked = false;
                if (selectDefaultEngine) selectDefaultEngine.value = "local";
                if (selectDegradation) selectDegradation.value = "2.0";
                if (inputSchemaOwner) inputSchemaOwner.value = "SH";
            }
        });
    }
}

// Color brightness calculation helper
function adjustColorBrightness(hex, percent) {
    let num = parseInt(hex.replace("#", ""), 16);
    let r = (num >> 16) + Math.round(255 * (percent / 100));
    let g = ((num >> 8) & 0x00FF) + Math.round(255 * (percent / 100));
    let b = (num & 0x0000FF) + Math.round(255 * (percent / 100));
    r = Math.min(255, Math.max(0, r));
    g = Math.min(255, Math.max(0, g));
    b = Math.min(255, Math.max(0, b));
    return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

function isColorLight(hex) {
    let num = parseInt(hex.replace("#", ""), 16);
    let r = num >> 16;
    let g = (num >> 8) & 0x00FF;
    let b = num & 0x0000FF;
    let brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness > 140;
}


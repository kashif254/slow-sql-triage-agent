@echo off
setlocal enabledelayedexpansion
REM ====================================================================
REM ORACLE DBA "Slow SQL" Triage Agent - Work PC Launcher (Non-Admin Mode)
REM Designed specifically for corporate PCs with zero administrator rights:
REM - Binds strictly to 127.0.0.1 (prevents Windows Firewall popup)
REM - Automatically detects user virtual environments (venv or .venv)
REM - Automatically launches browser to http://127.0.0.1:8000
REM ====================================================================

title ORACLE DBA "Slow SQL" Triage Agent (Work PC)
echo ====================================================================
echo  ORACLE DBA "Slow SQL" Triage Agent - Non-Admin Work Environment
echo ====================================================================
echo.

cd /d "%~dp0"

REM 1. Detect Python Executable (Local venv or WinPython)
if exist "venv\Scripts\python.exe" (
    echo [*] Found local virtual environment: venv
    set "PYTHON_EXE=venv\Scripts\python.exe"
) else if exist ".venv\Scripts\python.exe" (
    echo [*] Found local virtual environment: .venv
    set "PYTHON_EXE=.venv\Scripts\python.exe"
) else if exist "..\WinPython*\python\python.exe" (
    for /d %%D in ("..\WinPython*") do (
        if exist "%%~fD\python\python.exe" (
            echo [*] Found portable WinPython: %%~fD\python\python.exe
            set "PYTHON_EXE=%%~fD\python\python.exe"
        )
    )
) else if exist "C:\tmp\WinPython*\python\python.exe" (
    for /d %%D in ("C:\tmp\WinPython*") do (
        if exist "%%~fD\python\python.exe" (
            echo [*] Found portable WinPython in C:\tmp: %%~fD\python\python.exe
            set "PYTHON_EXE=%%~fD\python\python.exe"
        )
    )
) else if exist "WinPython*\python\python.exe" (
    for /d %%D in ("WinPython*") do (
        if exist "%%~fD\python\python.exe" (
            echo [*] Found portable WinPython: %%~fD\python\python.exe
            set "PYTHON_EXE=%%~fD\python\python.exe"
        )
    )
) else (
    echo [*] Using system user Python...
    set "PYTHON_EXE=python"
)

REM 2. Verify Python is callable
!PYTHON_EXE! --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo [!] ERROR: Python not found!
    echo     Please make sure Python is installed in your user profile
    echo     or extract WinPython into this folder.
    echo.
    pause
    exit /b 1
)

REM 3. Verify Dependencies (FastAPI, Uvicorn)
!PYTHON_EXE! -c "import fastapi, uvicorn" >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo [*] Installing required packages in user mode (no admin needed)...
    if exist "offline_wheels\*.whl" (
        echo [*] Found offline_wheels folder - Installing 100%% OFFLINE (no internet needed)...
        !PYTHON_EXE! -m pip install --no-index --find-links=offline_wheels -r requirements.txt
    ) else if exist "..\offline_wheels\*.whl" (
        echo [*] Found ..\offline_wheels folder - Installing 100%% OFFLINE (no internet needed)...
        !PYTHON_EXE! -m pip install --no-index --find-links=..\offline_wheels -r requirements.txt
    ) else (
        echo [*] Installing packages from PyPI network...
        !PYTHON_EXE! -m pip install -r requirements.txt
    )
    if %errorlevel% neq 0 (
        echo [!] Failed to install dependencies.
        echo     If air-gapped without internet, make sure 'offline_wheels' folder is present.
        echo     If your company uses a proxy, run:
        echo     pip install --proxy http://yourproxy:port -r requirements.txt
        pause
        exit /b 1
    )
)

echo.
echo [*] Starting Triage Server via configuration runner (reading config.json)...
echo.

REM 4. Run server runner (reads host, port, jump box name from config.json)
!PYTHON_EXE! run_server.py

pause

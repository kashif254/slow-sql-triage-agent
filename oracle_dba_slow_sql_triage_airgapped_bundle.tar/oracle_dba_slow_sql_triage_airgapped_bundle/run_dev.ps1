# ====================================================================
# ORACLE DBA "Slow SQL" Triage Agent - Local Dev Server Launcher (PowerShell)
# ====================================================================

Write-Host "[*] Starting ORACLE DBA 'Slow SQL' Triage Local Dev Server..." -ForegroundColor Cyan
Write-Host "[*] Working Directory: $PSScriptRoot" -ForegroundColor Gray

python -m uvicorn slow_sql.web.app:app --host 127.0.0.1 --port 8000 --reload

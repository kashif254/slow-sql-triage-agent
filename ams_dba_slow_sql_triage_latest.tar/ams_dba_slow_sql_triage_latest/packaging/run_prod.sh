#!/usr/bin/env bash
# ====================================================================
# ORACLE DBA "Slow SQL" Triage Agent - Production Launcher (Linux/Unix)
# ====================================================================

echo "[*] Starting ORACLE DBA \"Slow SQL\" Triage Agent in Production Mode..."

if ! python3 -c "import fastapi, uvicorn" 2>/dev/null; then
    echo "[!] Dependencies missing. Installing from requirements.txt..."
    pip3 install -r requirements.txt
fi

echo "[*] Launching Production ASGI Server on port 8000..."
echo "[*] Access the application in your browser at: http://localhost:8000"
echo "[*] Press Ctrl+C to terminate the server."
echo ""

exec uvicorn slow_sql.web.app:app --host 0.0.0.0 --port 8000 --workers 2

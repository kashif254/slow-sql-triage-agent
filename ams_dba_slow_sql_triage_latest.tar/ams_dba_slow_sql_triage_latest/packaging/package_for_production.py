"""
Oracle Slow SQL Triage - Production Packaging Tool
Packages the entire application into a self-contained, transportable zip bundle
ready for deployment on a corporate or production server.
"""

import os
import sys
import zipfile
import shutil
from pathlib import Path
from datetime import datetime

ROOT_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT_DIR))
DIST_DIR = ROOT_DIR / "dist"

def create_production_bundle():
    DIST_DIR.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_name = f"ORACLE_dba_slow_sql_triage_prod_{timestamp}.zip"
    zip_path = DIST_DIR / zip_name

    print(f"[*] Packaging ORACLE DBA Slow SQL Triage Agent into: {zip_path}")

    # Generate standalone collector SQL script for convenience
    collector_script = ROOT_DIR / "slow_sql" / "scripts" / "collector_generator.py"
    if collector_script.exists():
        from slow_sql.scripts.collector_generator import generate_collector_sql
        standalone_sql = ROOT_DIR / "slow_sql_collector.sql"
        standalone_sql.write_text(generate_collector_sql(), encoding="utf-8")
        print("[*] Generated standalone slow_sql_collector.sql")

    # Files and folders to include
    include_paths = [
        ROOT_DIR / "slow_sql",
        ROOT_DIR / "requirements.txt",
        ROOT_DIR / "pyproject.toml",
        ROOT_DIR / "run_dev.bat",
        ROOT_DIR / "run_dev.ps1",
        ROOT_DIR / "run_work_pc.bat",
        ROOT_DIR / "slow_sql_collector.sql",
        ROOT_DIR / "packaging" / "Dockerfile",
        ROOT_DIR / "packaging" / "run_prod.bat",
        ROOT_DIR / "packaging" / "run_prod.sh",
        ROOT_DIR / "README.md",
    ]

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for p in include_paths:
            if not p.exists():
                continue
            if p.is_file():
                arcname = p.relative_to(ROOT_DIR)
                zipf.write(p, arcname)
                print(f"  + Added file: {arcname}")
            elif p.is_dir():
                for file_path in p.rglob("*"):
                    if any(ignored in file_path.parts for ignored in ["__pycache__", ".pytest_cache", ".git", ".venv"]):
                        continue
                    if file_path.is_file():
                        arcname = file_path.relative_to(ROOT_DIR)
                        zipf.write(file_path, arcname)
                        print(f"  + Added file: {arcname}")

    # Also create a latest pointer copy
    latest_zip = DIST_DIR / "ORACLE_dba_slow_sql_triage_latest.zip"
    shutil.copy2(zip_path, latest_zip)

    print(f"\n[+] Production package created successfully!")
    print(f"    Bundle: {zip_path}")
    print(f"    Latest: {latest_zip}")
    print(f"    Size: {zip_path.stat().st_size / 1024:.1f} KB")
    print(f"\nInstructions for Production Deployment:")
    print(f"1. Transport {zip_name} to your production server.")
    print(f"2. Unzip the package: unzip {zip_name} (or Extract All on Windows)")
    print(f"3. Run: pip install -r requirements.txt")
    print(f"4. Launch with: run_prod.bat (Windows) or ./run_prod.sh (Linux)")

if __name__ == "__main__":
    create_production_bundle()

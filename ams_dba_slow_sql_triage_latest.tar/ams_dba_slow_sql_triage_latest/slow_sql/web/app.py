"""
Oracle Slow SQL Triage - Web Application Server
FastAPI backend providing REST APIs for plan parsing, data collector script generation,
and dual-engine (Local Offline / LLM Connected) triage.
"""

import json
from pathlib import Path
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException, Response
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, PlainTextResponse
from pydantic import BaseModel

from slow_sql.engine.parser import OracleDiagnosticParser
from slow_sql.engine.offline_triage import LocalOfflineTriageEngine
from slow_sql.engine.llm_triage import LLMConnectedTriageEngine
from slow_sql.scripts.collector_generator import generate_collector_sql
from slow_sql.scripts.sample_data import SAMPLE_BUNDLE_TEXT

app = FastAPI(
    title="AMS DBA \"Slow SQL\" Triage Agent",
    description="Deterministic and LLM-powered deep performance triage for Oracle SQL queries.",
    version="1.0.0"
)

STATIC_DIR = Path(__file__).parent / "static"
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
CONFIG_PATH = PROJECT_ROOT / "config.json"

def get_server_config() -> dict:
    """Reads configuration from config.json with fallback defaults."""
    defaults = {
        "server": {
            "bind_host": "0.0.0.0",
            "port": 8000,
            "public_host": "vbaw-spaces-mgt.itsso.gc.ca",
            "auto_open_browser": True
        },
        "triage_defaults": {
            "default_engine": "local",
            "default_provider": "gemini",
            "default_gemini_model": "gemini-1.5-flash",
            "degradation_threshold": 2.0,
            "default_schema_owner": "SH"
        }
    }
    if not CONFIG_PATH.exists():
        return defaults
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
            if "server" in cfg:
                defaults["server"].update(cfg["server"])
            if "triage_defaults" in cfg:
                defaults["triage_defaults"].update(cfg["triage_defaults"])
            return defaults
    except Exception:
        return defaults

def save_server_config(new_cfg: dict) -> bool:
    """Persists configuration to config.json."""
    try:
        current = get_server_config()
        if "server" in new_cfg:
            current["server"].update(new_cfg["server"])
        if "triage_defaults" in new_cfg:
            current["triage_defaults"].update(new_cfg["triage_defaults"])
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(current, f, indent=2)
        return True
    except Exception:
        return False


class ParseRequest(BaseModel):
    bundle_text: Optional[str] = ""
    execution_plan: Optional[str] = ""
    sql_text: Optional[str] = ""
    sql_id: Optional[str] = ""

class TriageRequest(BaseModel):
    bundle_text: Optional[str] = ""
    execution_plan: Optional[str] = ""
    index_snapshot: Optional[str] = ""
    sql_id: Optional[str] = ""
    sql_text: Optional[str] = ""
    phv_metrics: Optional[str] = ""
    table_stats: Optional[str] = ""
    sql_monitor: Optional[str] = ""
    profiles_baselines: Optional[str] = ""
    engine_mode: str = "local"  # "local" or "llm"
    provider: Optional[str] = "gemini"  # gemini, anthropic, openai, grok
    api_key: Optional[str] = ""
    model: Optional[str] = None

@app.get("/api/health")
async def health_check():
    cfg = get_server_config()
    server_cfg = cfg.get("server", {})
    return {
        "status": "ok",
        "agent": "AMS DBA \"Slow SQL\" Triage Agent",
        "version": "1.0.0",
        "public_host": server_cfg.get("public_host", "vbaw-spaces-mgt.itsso.gc.ca"),
        "port": server_cfg.get("port", 8000)
    }

@app.get("/api/config")
async def get_config_endpoint():
    """Returns the current server and triage configuration."""
    cfg = get_server_config()
    server_cfg = cfg.get("server", {})
    port = server_cfg.get("port", 8000)
    public_host = server_cfg.get("public_host", "vbaw-spaces-mgt.itsso.gc.ca")
    return {
        "config": cfg,
        "colleague_url": f"http://{public_host}:{port}",
        "local_url": f"http://127.0.0.1:{port}",
        "public_host": public_host,
        "port": port
    }

class ConfigUpdateRequest(BaseModel):
    server: Optional[Dict[str, Any]] = None
    triage_defaults: Optional[Dict[str, Any]] = None

@app.post("/api/config")
async def update_config_endpoint(req: ConfigUpdateRequest):
    """Updates and persists configuration to config.json."""
    update_data = {}
    if req.server:
        update_data["server"] = req.server
    if req.triage_defaults:
        update_data["triage_defaults"] = req.triage_defaults
    success = save_server_config(update_data)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to save configuration to config.json")
    return {"status": "saved", "config": get_server_config()}


@app.get("/api/collector-script")
async def get_collector_script(sql_id: Optional[str] = None, download: bool = False):
    """
    Returns the turnkey SQL*Plus script for collecting all Slow SQL telemetry.
    Can be previewed or downloaded as slow_sql_collector.sql.
    """
    script_content = generate_collector_sql(sql_id or "")
    if download:
        filename = f"slow_sql_collector_{sql_id}.sql" if sql_id else "slow_sql_collector.sql"
        return Response(
            content=script_content,
            media_type="application/sql",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'}
        )
    return PlainTextResponse(script_content)

@app.get("/api/sample-bundle")
async def get_sample_bundle():
    """Returns realistic production sample diagnostic bundle."""
    return {"bundle_text": SAMPLE_BUNDLE_TEXT}

@app.post("/api/parse-plan")
async def parse_plan_for_tables(req: ParseRequest):
    """
    Instantly parses the execution plan or bundle and returns detected tables
    so the UI can prompt the user to upload index snapshots for those specific tables.
    """
    if req.bundle_text:
        parsed = OracleDiagnosticParser.parse_bundle(req.bundle_text)
        tables = parsed.get("execution_plan", {}).get("tables_involved", [])
        sql_id = parsed.get("sql_id")
        phv = parsed.get("execution_plan", {}).get("phv")
        return {
            "tables_involved": tables,
            "sql_id": sql_id,
            "phv": phv,
            "phv_count": len(parsed.get("phv_metrics", [])),
            "has_indexes": len(parsed.get("indexes", [])) > 0,
            "has_stats": len(parsed.get("table_stats", [])) > 0
        }
    elif req.execution_plan:
        plan_parsed = OracleDiagnosticParser._parse_execution_plan(req.execution_plan)
        return {
            "tables_involved": plan_parsed.get("tables_involved", []),
            "sql_id": req.sql_id or "",
            "phv": plan_parsed.get("phv", ""),
            "phv_count": 0,
            "has_indexes": False,
            "has_stats": False
        }
    else:
        return {"tables_involved": [], "sql_id": "", "phv": ""}

@app.post("/api/triage")
async def execute_triage(req: TriageRequest):
    """
    Performs comprehensive triage analysis using either:
    1. Local Offline Heuristic Engine (air-gapped)
    2. LLM Connected Engine (Gemini, Claude, OpenAI, Grok)
    """
    # 1. Ingestion & Normalization
    if req.bundle_text and "=== SECTION:" in req.bundle_text:
        data = OracleDiagnosticParser.parse_bundle(req.bundle_text)
    else:
        # Build bundle or data structure from individual fields
        combined_text = []
        if req.sql_id or req.sql_text:
            combined_text.append(f"=== SECTION: SQL_METADATA ===\nSQL_ID: {req.sql_id or 'UNKNOWN'}\n--- SQL_TEXT ---\n{req.sql_text or ''}")
        if req.profiles_baselines:
            combined_text.append(f"=== SECTION: SQL_PROFILES_AND_BASELINES ===\n{req.profiles_baselines}")
        if req.phv_metrics:
            combined_text.append(f"=== SECTION: PHV_METRICS ===\n{req.phv_metrics}")
        if req.table_stats:
            combined_text.append(f"=== SECTION: TABLE_STATS_FRESHNESS ===\n{req.table_stats}")
        if req.index_snapshot:
            combined_text.append(f"=== SECTION: TABLE_INDEXES ===\n{req.index_snapshot}")
        if req.sql_monitor:
            combined_text.append(f"=== SECTION: SQL_MONITOR ===\n{req.sql_monitor}")
        if req.execution_plan:
            combined_text.append(f"=== SECTION: EXECUTION_PLAN_ADVANCED ===\n{req.execution_plan}")

        if combined_text:
            data = OracleDiagnosticParser.parse_bundle("\n\n".join(combined_text))
        else:
            raise HTTPException(status_code=400, detail="No diagnostic data provided. Please upload a bundle or execution plan.")

    # Override SQL_ID / SQL_TEXT if passed explicitly
    if req.sql_id:
        data["sql_id"] = req.sql_id
    if req.sql_text:
        data["sql_text"] = req.sql_text

    # 2. Run Local Offline Triage Engine
    local_engine = LocalOfflineTriageEngine(data)
    local_report = local_engine.run_triage()

    # 3. If LLM Connected mode is selected, invoke LLM Engine
    if req.engine_mode == "llm":
        if not req.api_key:
            raise HTTPException(
                status_code=400, 
                detail=f"API Key required for LLM Connected mode with {req.provider or 'Gemini'}."
            )
        try:
            llm_engine = LLMConnectedTriageEngine(
                provider=req.provider or "gemini",
                api_key=req.api_key,
                model=req.model
            )
            llm_result = await llm_engine.analyze(data, local_report)
            return {
                "engine_mode": "llm",
                "provider": req.provider,
                "local_report": local_report,
                "llm_narrative": llm_result["llm_narrative"],
                "data_summary": {
                    "sql_id": data.get("sql_id"),
                    "tables_involved": data.get("execution_plan", {}).get("tables_involved", []),
                    "phv": data.get("execution_plan", {}).get("phv"),
                    "phv_count": len(data.get("phv_metrics", []))
                }
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"LLM Triage failed: {str(e)}")

    # Otherwise return local report
    return {
        "engine_mode": "local",
        "local_report": local_report,
        "llm_narrative": None,
        "data_summary": {
            "sql_id": data.get("sql_id"),
            "tables_involved": data.get("execution_plan", {}).get("tables_involved", []),
            "phv": data.get("execution_plan", {}).get("phv"),
            "phv_count": len(data.get("phv_metrics", []))
        }
    }

# Mount static web UI files
if STATIC_DIR.exists():
    app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    cfg = get_server_config()
    server_cfg = cfg.get("server", {})
    bind_host = server_cfg.get("bind_host", "0.0.0.0")
    port = int(server_cfg.get("port", 8000))
    uvicorn.run("slow_sql.web.app:app", host=bind_host, port=port, reload=True)

